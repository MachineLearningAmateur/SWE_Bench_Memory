"""Credential-safe deployment check outside the scored benchmark."""
import contextlib
import io
import json
import time
from datetime import datetime, timezone
from pathlib import Path

from src.failure_corpus import write_json
from src.failure_pilot import validate, validate_contexts

out = Path('/workspace/results/failure50_verified10_v1')
validate(out)
validate_contexts(out)
receipt = {'timestamp_utc': datetime.now(timezone.utc).isoformat(),
           'outside_scored_attempts': True, 'success': False}
started = time.monotonic()
try:
    with contextlib.redirect_stdout(io.StringIO()), contextlib.redirect_stderr(io.StringIO()):
        from src.model_profiles import resolve_profile
        from src.gpt_oss_tool_model import RepairingToolLitellmModel
        profile = resolve_profile('gpt_oss_20b')
        model = RepairingToolLitellmModel(model_name=profile['model_name'],
                    model_kwargs=profile['model_kwargs'], cost_tracking='ignore_errors')
        messages = [{'role': 'user', 'content': 'Call bash with command printf endpoint-ready. This is an endpoint connectivity check.'}]
        first = model._query(messages, max_tokens=1024, timeout=45, num_retries=0)
        choice = first.choices[0]
        calls = choice.message.tool_calls or []
        assert choice.finish_reason == 'tool_calls' and len(calls) == 1
        call = calls[0]
        assert call.function.name == 'bash'
        arguments = json.loads(call.function.arguments)
        assert isinstance(arguments.get('command'), str) and arguments['command'].strip()
        messages += [choice.message.model_dump(exclude_none=True),
                     {'role': 'tool', 'tool_call_id': call.id, 'content': 'endpoint-ready'},
                     {'role': 'user', 'content': 'The tool output was received. Call bash with command printf roundtrip-ready.'}]
        second = model._query(messages, max_tokens=1024, timeout=45, num_retries=0)
        calls2 = second.choices[0].message.tool_calls or []
        assert second.choices[0].finish_reason == 'tool_calls' and len(calls2) == 1
        assert calls2[0].function.name == 'bash'
        assert json.loads(calls2[0].function.arguments).get('command')
        receipt.update(success=True, structured_tool_call=True, tool_result_roundtrip=True,
                       deployment=profile['deployment'], model_name=profile['model_name'])
except Exception as exc:
    receipt.update(error_type=type(exc).__name__, http_status=getattr(exc, 'status_code', None))
receipt['elapsed_seconds'] = round(time.monotonic()-started, 3)
write_json(out / 'restart_preflight.json', receipt)
print(json.dumps(receipt))
raise SystemExit(0 if receipt['success'] else 1)
