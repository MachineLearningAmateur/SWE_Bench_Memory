"""One-off independent audit of the prepared experiment, without solver calls."""
import collections
import json
import sqlite3
from datetime import datetime, timezone
from pathlib import Path

import numpy as np

from src.failure_corpus import digest, load_tokenizer, read_json, rooted, write_json
from src.failure_pilot import CONDITIONS, validate, validate_contexts

out = Path('results/failure50_verified10_v1').resolve()
manifest = validate(out)
validate_contexts(out)
cfg = manifest['config']
corpus = rooted(cfg['corpus'])
cm = read_json(corpus / 'manifest.json')
frozen = read_json(out / 'contexts_manifest.json')
assert len(frozen['files']) == 150
assert digest(out / 'retrieval_audit.json') == frozen['retrieval_audit_sha256']
assert digest(out / 'source_citation_diagnostics.json') == frozen['source_citation_diagnostics_sha256']
assert digest(corpus / 'embeddings.npy') == frozen['embeddings_sha256']
tokenizer = load_tokenizer(cfg['models']['tokenizer'])
db = sqlite3.connect((corpus / 'corpus.sqlite').as_uri() + '?mode=ro', uri=True)
db.row_factory = sqlite3.Row
chunks = {r['chunk_id']: dict(r) for r in db.execute('SELECT * FROM chunks')}
documents = {r['id']: dict(r) for r in db.execute('SELECT * FROM documents')}
edges = {tuple(r) for r in db.execute('SELECT source,relation,target FROM edges')}
source_ids = {r['id'] for r in db.execute('SELECT id FROM cases')}
stats = collections.defaultdict(list)
types = collections.defaultdict(collections.Counter)
graph_contexts = different_contexts = 0
checklists = set()
split_ids = {}
for split, filename in [('development', 'development.json'), ('pilot', 'tasks.json')]:
    tasks = read_json(out / filename)
    split_ids[split] = {t['instance_id'] for t in tasks}
    assert not split_ids[split] & source_ids
    for task in tasks:
        bundles = {}
        for condition in CONDITIONS:
            bundle = read_json(out / 'contexts' / split / task['instance_id'] / f'{condition}.json')
            bundles[condition] = bundle
            assert bundle['condition'] == condition and bundle['query'] == task['problem_statement']
            tokens = len(tokenizer.encode(bundle['context'], add_special_tokens=False))
            assert tokens == bundle['metadata']['memory_tokens'] and tokens <= 4000
            stats[condition].append(tokens)
            if condition == 'no_memory':
                assert bundle['context'] == '' and not bundle['selected']
            if condition == 'checklist':
                checklists.add(bundle['context'])
            if condition in ('bm25', 'hybrid_rag', 'graph_rag'):
                assert len(bundle['metadata']['candidate_ids']) == bundle['metadata']['candidate_count'] <= 100
                assert len(set(bundle['metadata']['candidate_ids'])) == bundle['metadata']['candidate_count']
            if condition == 'graph_rag':
                seeds = set()
                for chunk_id in bundle['metadata']['shared_seed_ids']:
                    doc = documents[chunks[chunk_id]['doc_id']]
                    seeds.add(doc['id'])
                    if doc['kind'] == 'relation':
                        provenance = json.loads(doc['provenance'])
                        seeds.update((provenance['source'], provenance['target']))
                for chunk_id, path in bundle['metadata']['graph_candidate_paths'].items():
                    assert 1 <= len(path) <= 2
                    previous = None
                    for edge in path:
                        assert (edge['source'], edge['relation'], edge['target']) in edges
                        assert edge['direction'] in ('forward', 'reverse')
                        begin, end = (edge['source'], edge['target']) if edge['direction'] == 'forward' else (edge['target'], edge['source'])
                        assert begin in seeds if previous is None else begin == previous
                        previous = end
                    assert previous == chunks[chunk_id]['doc_id']
            intervals = collections.defaultdict(list)
            for row in bundle['selected']:
                chunk = chunks[row['chunk_id']]
                assert chunk['doc_id'] == row['document_id']
                assert chunk['start_char'] <= row['start_char'] < row['end_char'] <= chunk['end_char']
                assert row['case_id'] in source_ids
                document = documents[row['document_id']]
                assert document['case_id'] == row['case_id']
                assert document['text'][row['start_char']:row['end_char']] in bundle['context']
                assert row['chunk_id'] in bundle['metadata']['candidate_ids']
                assert len(row['graph_path']) <= 2
                assert condition == 'graph_rag' or not row['graph_path']
                if condition == 'graph_rag':
                    assert row['graph_path'] == bundle['metadata']['graph_candidate_paths'].get(row['chunk_id'], [])
                for left, right in intervals[row['document_id']]:
                    assert row['end_char'] <= left or row['start_char'] >= right
                intervals[row['document_id']].append((row['start_char'], row['end_char']))
                types[condition][row['kind']] += 1
        assert bundles['hybrid_rag']['metadata']['shared_seed_ids'] == bundles['graph_rag']['metadata']['shared_seed_ids']
        graph_contexts += any(r['graph_path'] for r in bundles['graph_rag']['selected'])
        different_contexts += bundles['hybrid_rag']['context'] != bundles['graph_rag']['context']
assert not split_ids['development'] & split_ids['pilot']
assert len(checklists) == 1
assert not list((out / 'runs').rglob('run.json'))
assert read_json(out / 'status.json') == {'state': 'ready', 'completed': 0, 'total': 50}
environments = read_json(out / 'environment_preflight.json')
assert len(environments) == 10 and all(r['returncode'] == 0 for r in environments)
vectors = np.load(corpus / 'embeddings.npy', mmap_mode='r')
assert vectors.shape == (1622, 1024) and np.isfinite(vectors).all()
norm_error = float(np.max(np.abs(np.linalg.norm(vectors, axis=1) - 1)))
assert norm_error < 1e-5
report = {
    'verified_utc': datetime.now(timezone.utc).isoformat(),
    'state': 'local_preparation_complete_waiting_for_user_endpoint',
    'source_commit': manifest['source_commit'],
    'source_artifacts_verified': len(cm['source']['artifacts']),
    'corpus': cm['counts'], 'corpus_sha256': cm['corpus_sha256'],
    'experiment_manifest_sha256': digest(out / 'manifest.json'),
    'contexts_manifest_sha256': digest(out / 'contexts_manifest.json'),
    'models': cfg['models'], 'dataset': cfg['pilot'],
    'context_bundles': len(frozen['files']),
    'token_counts': {c: {'min': min(v), 'max': max(v), 'mean': sum(v)/len(v)} for c, v in stats.items()},
    'selected_record_types': dict(types),
    'queries_with_selected_graph_paths': graph_contexts,
    'queries_with_different_hybrid_graph_contexts': different_contexts,
    'embedding_shape': list(vectors.shape), 'embedding_max_norm_error': norm_error,
    'official_task_environment_checks_passed': len(environments),
    'scored_solver_attempts': 0, 'automatic_start': False,
    'checks': ['frozen code/config/corpus/context hashes', 'all 150 token budgets',
               'source offsets and nonoverlap', 'shared hybrid/graph seeds',
               '100 candidate and two-hop bounds', 'graph path edge membership, direction and continuity', 'identical checklists',
               'disjoint source/development/pilot IDs', 'finite normalized embeddings'],
    'limitations': ['No solver outcomes yet.', 'Graph exposure is not evidence of usefulness.',
                    'Source citation diagnostic is not independent unseen-task relevance.'],
}
Path('audit/failure50_v1').mkdir(parents=True, exist_ok=True)
write_json(Path('audit/failure50_v1/preparation.json'), report)
print(json.dumps(report, indent=2))
