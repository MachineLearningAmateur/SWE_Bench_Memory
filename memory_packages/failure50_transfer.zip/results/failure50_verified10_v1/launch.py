"""Keep the benchmark independent of the interactive tool session."""
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

from src.failure_corpus import read_json, write_json
from src.failure_pilot import validate, validate_contexts

out = Path('/workspace/results/failure50_verified10_v1')
validate(out)
validate_contexts(out)
assert read_json(out / 'restart_preflight.json')['success']
assert read_json(out / 'status.json')['state'] == 'ready'
assert not (out / 'execution.lock').exists()
with (out / 'launch.json').open('x', encoding='utf-8') as handle:
    import json
    json.dump({'started_utc': datetime.now(timezone.utc).isoformat(),
               'trigger': 'User confirmed the model deployment is available.',
               'preflight': 'restart_preflight.json'}, handle, indent=2)
write_json(out / 'execution_blocker.json', {
    'state': 'cleared', 'reason': 'Deployment passed the existing solver adapter preflight.',
    'preflight': 'restart_preflight.json', 'launch': 'launch.json'})
with (out / 'runner.stdout.log').open('x', encoding='utf-8') as log:
    result = subprocess.run([sys.executable, '-m', 'src.failure_pilot', 'run', '--output', str(out)],
                            cwd='/workspace', stdout=log, stderr=subprocess.STDOUT)
write_json(out / 'runner_exit.json', {'exit_code': result.returncode,
                                     'finished_utc': datetime.now(timezone.utc).isoformat()})
raise SystemExit(result.returncode)
