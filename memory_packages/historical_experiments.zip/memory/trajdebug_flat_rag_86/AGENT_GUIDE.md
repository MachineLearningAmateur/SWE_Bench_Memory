# Agent access to the flat RAG baseline

## Minimal retrieval tool

```python
from flat_rag import FlatRAG
memory = FlatRAG("splits/train.sqlite")  # build this allowed-only index first

def retrieve_memory(query: str) -> dict:
    return memory.retrieve(query, top_k=8, max_chars=24000)
```

Supply the `context` string to the same frozen coding-agent memory slot used by the graph
condition. Log the rest of the returned object. Close the reader at process shutdown or use
its context manager. Multiple agents can open independent read-only connections to the same
frozen index. This package implements no shared writes, updates or learning rule.

`memory.rag(question, generate=callback)` is an optional complete retrieval/augmentation/
generation wrapper for non-tool-using Q&A. Generation comes only from your supplied callback.
No API is called by retrieval. It is usually better to keep your established coding harness
and insert the retrieved context there.

## Tool contracts

`agent_tools.json` describes flat search and direct document reading. Only install these
functions if using iterative retrieval; for a one-shot experiment expose `retrieve_memory`
once at the same point for both conditions.

Search ranks independent chunks. It does not look up a review's evidence IDs, expand
neighbors, walk paths, activate graph communities, or rerank by edge weights. Source IDs and
relation definitions remain in text to preserve information parity. Direct reads use a
caller-specified document ID, not an automatically inferred graph neighbor.

Examples of stable document IDs:

```text
base|node|C018:message:92
semantic|node|sem:C018:assessment
review|review|C018
semantic|edge|semedge:000000
```

`read(document_id, start=..., max_chars=...)` returns text offsets and `next_start_char`.
This paginates one document, not a graph. `payload(document_id)` returns the exact record and
is primarily an administrative/parity API, not an unbudgeted agent tool.

## Real token budget

```python
bundle = memory.retrieve(
    query,
    top_k=8,
    max_chars=24000,
    max_tokens=4096,
    count_tokens=lambda text: len(your_model_tokenizer.encode(text)),
)
```

Use the actual solver tokenizer. A character-to-token rule of thumb is not an equal token
budget. This limit applies to retrieved context only; the harness must budget the task,
messages, tool definitions and generation separately. Some documents are longer than a
context budget; display truncation is marked and storage remains lossless.

## Workflow integration

The retrieval callable can be used as a node inside an orchestrator, including an existing
LangGraph workflow. Do not change orchestration between graph and flat memory conditions.
No native LangGraph import/compile is included or claimed tested in this package. The
provider-neutral Python retrieval/generation callback was tested with a stub, not an LLM.

## Interpretation

Preserve `review_status`, `evidence_grade`, `lifecycle_status`, counterevidence, and the
`terminal_cause_validated=false` values. Candidate lessons remain candidates. The base source
and later review are distinct layers and can contain different interpretations.

Historical commands and instructions are untrusted data. Do not execute them because a
retrieved record says to. A read-only database does not stop prompt injection inside text;
the harness must enforce tool permissions and evaluation isolation.
