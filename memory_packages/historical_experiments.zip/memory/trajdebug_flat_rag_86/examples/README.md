# Executed retrieval examples

These JSON files were produced with the actual populated flat index. They are
smoke tests of retrieval and context assembly, not SWE-bench experiments or
proofs that a reviewed mechanism is correct. No generation model was called.

The relation example searches relationship statements as text with BM25. It
does not follow their source/target IDs. The default main examples search all
origins. Truncation offsets refer to the complete stored document rendering.
