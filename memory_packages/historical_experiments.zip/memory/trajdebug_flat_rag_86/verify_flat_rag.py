"""Verify every preserved record, source file, chunk and graph round trip.

Works offline. Optional original packages allow direct source comparisons.
"""
from __future__ import annotations
import argparse
from collections import Counter
import gzip
import hashlib
import json
from pathlib import Path
import sqlite3
import zipfile
from flat_core import canonical,digest,text_digest,leaves
from build_flat_rag import rebuild_graph,member
from flat_rag import DEFAULT_DB

def verify(dbpath:Path=DEFAULT_DB,*,full_package:Path|None=None,review_package:Path|None=None,check_jsonl:bool=True)->dict:
    db=sqlite3.connect(dbpath.resolve().as_uri()+'?mode=ro',uri=True);db.row_factory=sqlite3.Row
    def require(condition:bool,message:str):
        if not condition:raise AssertionError(message)
    require(db.execute('PRAGMA integrity_check').fetchone()[0]=='ok','SQLite integrity')
    require(not db.execute('PRAGMA foreign_key_check').fetchall(),'Foreign keys')
    tables={r[0] for r in db.execute("SELECT name FROM sqlite_master WHERE type='table'")}
    require('edges' not in tables and 'adjacency' not in tables and 'neighbors' not in tables,'Unexpected traversal table')
    artifacts={}
    for origin in ['base','semantic']:
        reconstructed=rebuild_graph(db,origin)
        expected=db.execute('SELECT canonical_sha256 FROM artifact_headers WHERE origin=?',(origin,)).fetchone()[0]
        require(digest(reconstructed)==expected,origin+' canonical graph digest')
        artifacts[origin]=reconstructed
    review=json.loads(db.execute("SELECT header_json FROM artifact_headers WHERE origin='review'").fetchone()[0])
    review['cases']=[json.loads(r[0]) for r in db.execute("SELECT payload_json FROM documents WHERE origin='review' AND kind='review' ORDER BY ordinal")]
    require(digest(review)==db.execute("SELECT canonical_sha256 FROM artifact_headers WHERE origin='review'").fetchone()[0],'Review digest')
    if full_package:
        with zipfile.ZipFile(full_package) as z:
            require(artifacts['base']==json.loads(member(z,'data/graph.json')),'Original base graph equality')
            for row in db.execute('SELECT * FROM source_bytes'):
                require(row['data']==member(z,'data/raw_sources/'+row['case_id']+'.json'),'Original raw bytes '+row['case_id'])
    if review_package:
        with zipfile.ZipFile(review_package) as z:
            require(artifacts['semantic']==json.loads(member(z,'semantic_overlay.json')),'Original semantic overlay equality')
            require(review==json.loads(member(z,'semantic_reviews.json')),'Original reviews equality')
    # Whole source JSON reconstructed independently from the flat base-node records.
    nd={n['id']:n for n in artifacts['base']['nodes']}
    rawdocs={};message_count=0;rawbytes=0
    for row in db.execute('SELECT * FROM source_bytes ORDER BY case_id'):
        cid=row['case_id'];raw=row['data'];source=json.loads(raw)
        require(hashlib.sha256(raw).hexdigest()==row['sha256'],'Raw SHA256 '+cid)
        require(hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()==row['git_blob_sha1'],'Raw Git hash '+cid)
        restored=dict(nd['source:'+cid]['properties']['document_fields_other_than_messages'])
        restored['messages']=[nd[f'{cid}:message:{i}']['properties']['raw_message'] for i in range(len(source['messages']))]
        require(restored==source,'Source JSON reconstruction '+cid)
        rawdocs[cid]=source;message_count+=len(source['messages']);rawbytes+=len(raw)
    # Verify EVERY source/semantic pointer and optional character span, not just counts.
    def ptr(doc,p):
        for part in p.split('/')[1:]:
            key=part.replace('~1','/').replace('~0','~')
            doc=doc[int(key)] if isinstance(doc,list) else doc[key]
        return doc
    evidence_count=0
    for origin in ['base','semantic']:
        for record in artifacts[origin]['nodes']+artifacts[origin]['edges']:
            evidence=list(record.get('evidence',[]))
            sr=record.get('properties',{}).get('source_ref')
            if sr:evidence.append(sr)
            for ev in evidence:
                if not isinstance(ev,dict) or 'json_pointer' not in ev:continue
                val=ptr(rawdocs[ev['case_id']],ev['json_pointer'])
                if 'json_value_sha256' in ev:
                    actual = (hashlib.sha256(json.dumps(val,ensure_ascii=False,separators=(',',':'),allow_nan=False).encode('utf-8')).hexdigest() if origin=='base' else digest(val))
                    require(actual==ev['json_value_sha256'],'Evidence value digest '+origin+' '+record['id'])
                if 'span_sha256' in ev:require(text_digest(val[ev['start_char']:ev['end_char']])==ev['span_sha256'],'Evidence span digest')
                evidence_count+=1
    cited=0
    for r in review['cases']:
        require(r['case_id'] in rawdocs,'Review membership')
        for e in r['evidence']:
            require(digest(rawdocs[r['case_id']]['messages'][e['message_index']])==e['json_value_sha256'],'Review cited message equality')
            cited+=1
    ndocs=nchunks=0
    for row in db.execute('SELECT * FROM documents ORDER BY doc_id'):
        p=json.loads(row['payload_json'])
        require(text_digest(row['payload_json'])==row['payload_sha256'],'Payload hash '+row['doc_id'])
        require(text_digest(row['text'])==row['text_sha256'],'Text hash '+row['doc_id'])
        # All original values, not a lossy summary, occur in the document rendering.
        for path,value in leaves(p):
            label='string' if isinstance(value,str) else 'json'
            block=path+' ['+label+']\n'+(value if isinstance(value,str) else canonical(value))
            require(block in row['text'],'Missing rendered value '+row['doc_id']+path)
        end=0;part=-1;seen=False
        for ch in db.execute('SELECT * FROM chunks WHERE doc_id=? ORDER BY part',(row['doc_id'],)):
            require(ch['part']==part+1,'Chunk sequence')
            require(ch['start_char']<=end,'Chunk coverage gap')
            require(ch['text']==row['text'][ch['start_char']:ch['end_char']],'Chunk content changed')
            require(text_digest(ch['text'])==ch['sha256'],'Chunk digest')
            end=ch['end_char'];part=ch['part'];seen=True;nchunks+=1
        require(seen and end==len(row['text']),'Unindexed document suffix')
        ndocs+=1
    njsonl=0
    if check_jsonl:
        path=dbpath.parent/'flat_documents.jsonl.gz'
        with gzip.open(path,'rt',encoding='utf-8') as f:
            for line in f:
                d=json.loads(line);row=db.execute('SELECT * FROM documents WHERE doc_id=?',(d['doc_id'],)).fetchone()
                require(row is not None,'JSONL document absent from index')
                require(canonical(d['payload'])==row['payload_json'],'JSONL payload mismatch')
                for k in ['origin','kind','source_id','ordinal','payload_sha256','text','text_sha256','guard']:
                    require(d[k]==row[k],'JSONL field mismatch '+k)
                require(d['case_ids']==[c[0] for c in db.execute('SELECT case_id FROM document_cases WHERE doc_id=? ORDER BY case_id',(d['doc_id'],))],'JSONL access scope')
                njsonl+=1
        require(njsonl==ndocs,'JSONL count mismatch')
    result={'status':'PASS','sources':len(rawdocs),'original_bytes':rawbytes,'complete_messages':message_count,
            'base_graph_reconstruction':'equal','semantic_overlay_reconstruction':'equal','review_reconstruction':'equal',
            'documents_verified':ndocs,'chunks_verified':nchunks,'lossless_rendering_verified':ndocs,
            'jsonl_records_verified':njsonl,'source_evidence_pointers_checked':evidence_count,'review_cited_messages_checked':cited,
            'all_chunks_cover_complete_documents':True,'no_graph_traversal_tables':True,
            'direct_full_package_comparison':bool(full_package),'direct_review_package_comparison':bool(review_package),
            'scientific_validation':'Not performed; these are preservation and implementation checks only.'}
    db.close();return result

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--db',type=Path,default=DEFAULT_DB);p.add_argument('--full-package',type=Path);p.add_argument('--review-package',type=Path);p.add_argument('--out',type=Path)
    a=p.parse_args();r=verify(a.db,full_package=a.full_package,review_package=a.review_package)
    text=json.dumps(r,indent=2)+'\n'
    if a.out:a.out.write_text(text)
    print(text,end='')
if __name__=='__main__':main()
