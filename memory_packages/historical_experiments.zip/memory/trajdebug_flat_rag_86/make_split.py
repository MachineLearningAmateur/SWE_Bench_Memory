"""Build an allowed-only index BEFORE benchmark evaluation (no held-out IDF leakage).

The original full parity database remains unchanged. The new database includes
only allowed documents, source bytes and case records. Any multi-case record
that includes an excluded contributor is omitted (fail closed). No new semantics.
"""
from __future__ import annotations
import argparse
import json
from pathlib import Path
import shutil
import sqlite3
from flat_core import canonical
from flat_rag import FlatRAG,DEFAULT_DB

def make_split(source:Path,out:Path,*,exclude_repository=(),exclude_issue=(),exclude_case=())->dict:
    source=source.resolve();out=out.resolve()
    if out.exists():raise FileExistsError(f'Refusing to overwrite {out}')
    out.parent.mkdir(parents=True,exist_ok=True)
    try:
        with FlatRAG(source,exclude_repository=exclude_repository,exclude_issue=exclude_issue,exclude_case=exclude_case) as src:
            scope,params=src._scope_sql()
            blocked=[r[0] for r in src.db.execute('SELECT d.doc_id FROM documents d WHERE NOT ('+scope+')',params)]
            badcases=[r[0] for r in src.db.execute('SELECT case_id,repository,issue_group FROM cases') if r['case_id'] in exclude_case or r['repository'] in exclude_repository or r['issue_group'] in exclude_issue]
            if not badcases:raise ValueError('No excluded cases matched; refusing an accidental no-op split')
            dest=sqlite3.connect(out);src.db.backup(dest)
        dest.execute('PRAGMA foreign_keys=ON')
        dest.execute('CREATE TEMP TABLE blocked(id TEXT PRIMARY KEY)')
        dest.executemany('INSERT INTO blocked VALUES(?)',[(i,) for i in blocked])
        # Rebuild FTS after deleting chunks, so held-out text affects neither hits nor IDF.
        dest.execute('DELETE FROM chunks WHERE doc_id IN (SELECT id FROM blocked)')
        dest.execute('DELETE FROM document_cases WHERE doc_id IN (SELECT id FROM blocked)')
        dest.execute('DELETE FROM documents WHERE doc_id IN (SELECT id FROM blocked)')
        dest.executemany('DELETE FROM source_bytes WHERE case_id=?',[(c,) for c in badcases])
        dest.executemany('DELETE FROM cases WHERE case_id=?',[(c,) for c in badcases])
        # Full-corpus headers are audit-only, but remove them from a strict subset too.
        dest.execute('DELETE FROM artifact_headers');dest.execute('DELETE FROM build_metadata')
        config={'excluded_repositories':list(exclude_repository),'excluded_issues':list(exclude_issue),'excluded_cases':list(exclude_case),'strict_split_index':True,
                'full_corpus_parity_not_claimed_for_subset':True,'removed_cases':len(badcases),'remaining_cases':dest.execute('SELECT count(*) FROM cases').fetchone()[0],
                'remaining_documents':dest.execute('SELECT count(*) FROM documents').fetchone()[0],'remaining_chunks':dest.execute('SELECT count(*) FROM chunks').fetchone()[0],
                'shared_record_policy':'exclude if ANY contributing case is excluded; no partial claim rewriting'}
        dest.execute('INSERT INTO build_metadata VALUES(?,?)',('build_scope',canonical(config)))
        dest.execute("INSERT INTO chunk_fts(chunk_fts) VALUES('rebuild')")
        dest.commit();dest.execute('VACUUM')
        if dest.execute('PRAGMA foreign_key_check').fetchall():raise AssertionError('Dangling references')
        if dest.execute('PRAGMA integrity_check').fetchone()[0]!='ok':raise AssertionError('Integrity check failed')
        dest.close();out.with_suffix('.scope.json').write_text(json.dumps(config,indent=2)+'\n')
        return config
    except Exception:
        try:dest.close()
        except Exception:pass
        if out.exists():out.unlink()
        raise

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--db',type=Path,default=DEFAULT_DB);p.add_argument('--out',type=Path,required=True)
    for flag in ['exclude-repository','exclude-issue','exclude-case']:p.add_argument('--'+flag,action='append',default=[])
    a=p.parse_args();print(json.dumps(make_split(a.db,a.out,exclude_repository=a.exclude_repository,exclude_issue=a.exclude_issue,exclude_case=a.exclude_case),indent=2))
if __name__=='__main__':main()
