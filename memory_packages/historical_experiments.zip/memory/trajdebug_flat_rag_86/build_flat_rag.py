"""Flatten the two delivered graph artifacts + reviews with lossless payload parity.

Usage: python build_flat_rag.py --full-package ...zip --review-package ...zip --out data
No model/network calls. Does NOT execute source code. Output must be new.
"""
from __future__ import annotations
import argparse
from collections import Counter,defaultdict
import gzip
import hashlib
import json
from pathlib import Path
import shutil
import sqlite3
import tempfile
from typing import Any
import zipfile
from flat_core import canonical,digest,text_digest,render,chunks,review_guard,CHUNK_SIZE,CHUNK_OVERLAP

SCHEMA='''
PRAGMA foreign_keys=ON;
CREATE TABLE cases(case_id TEXT PRIMARY KEY,repository TEXT NOT NULL,issue_group TEXT NOT NULL,metadata_json TEXT NOT NULL);
CREATE TABLE documents(doc_id TEXT PRIMARY KEY,origin TEXT NOT NULL,kind TEXT NOT NULL,source_id TEXT NOT NULL,ordinal INTEGER NOT NULL,payload_json TEXT NOT NULL,payload_sha256 TEXT NOT NULL,text TEXT NOT NULL,text_sha256 TEXT NOT NULL,guard TEXT NOT NULL);
CREATE TABLE document_cases(doc_id TEXT NOT NULL REFERENCES documents(doc_id),case_id TEXT NOT NULL REFERENCES cases(case_id),PRIMARY KEY(doc_id,case_id));
CREATE INDEX documents_origin_kind ON documents(origin,kind);
CREATE INDEX membership_case ON document_cases(case_id,doc_id);
CREATE TABLE chunks(rowid INTEGER PRIMARY KEY,chunk_id TEXT UNIQUE NOT NULL,doc_id TEXT NOT NULL REFERENCES documents(doc_id),part INTEGER NOT NULL,start_char INTEGER NOT NULL,end_char INTEGER NOT NULL,text TEXT NOT NULL,sha256 TEXT NOT NULL);
CREATE INDEX chunks_doc ON chunks(doc_id,part);
CREATE VIRTUAL TABLE chunk_fts USING fts5(text,content='chunks',content_rowid='rowid',tokenize='unicode61');
CREATE TABLE source_bytes(case_id TEXT PRIMARY KEY REFERENCES cases(case_id),data BLOB NOT NULL,sha256 TEXT NOT NULL,git_blob_sha1 TEXT NOT NULL);
CREATE TABLE artifact_headers(origin TEXT PRIMARY KEY,header_json TEXT NOT NULL,canonical_sha256 TEXT NOT NULL,file_sha256 TEXT NOT NULL);
CREATE TABLE build_metadata(key TEXT PRIMARY KEY,value_json TEXT NOT NULL);
'''

def member(z:zipfile.ZipFile,suffix:str)->bytes:
    names=[n for n in z.namelist() if n.endswith('/'+suffix)]
    if len(names)!=1:
        raise ValueError(f'Expected exactly one {suffix}; found {len(names)}')
    info=z.getinfo(names[0])
    if info.file_size>250_000_000:
        raise ValueError('Source member too large')
    return z.read(info)

def scopes_for_graph(g:dict)->dict[str,set[str]]:
    """Origin-based access labels only. Not a graph traversal/retrieval algorithm.

    Shared identity records are scoped to all contributing cases and fail closed
    when any contributor is excluded. Preserve that rule across BOTH arms.
    """
    scopes={n['id']:({n['case_id']} if n.get('case_id') else set()) for n in g['nodes']}
    owners={n['id']:n.get('case_id') for n in g['nodes']}
    for e in g['edges']:
        direct={owners.get(e['source']),owners.get(e['target']),e.get('case_id')}
        direct.update(x.get('case_id') for x in e.get('evidence',[]))
        direct.discard(None)
        for nid in (e['source'],e['target']):
            if owners.get(nid) is None:
                scopes[nid].update(direct)
    return scopes

def edge_cases(e:dict,owners:dict)->set[str]:
    cs={owners.get(e['source']),owners.get(e['target']),e.get('case_id')}
    cs.update(x.get('case_id') for x in e.get('evidence',[]));cs.discard(None)
    return cs

def rebuild_graph(db:sqlite3.Connection,origin:str)->dict:
    r=db.execute('SELECT header_json FROM artifact_headers WHERE origin=?',(origin,)).fetchone()
    if not r: raise KeyError(origin)
    out=json.loads(r[0])
    for kind,key in [('node','nodes'),('edge','edges')]:
        out[key]=[json.loads(x[0]) for x in db.execute('SELECT payload_json FROM documents WHERE origin=? AND kind=? ORDER BY ordinal',(origin,kind))]
    if origin=='base':
        out['case_index']=[json.loads(x[0]) for x in db.execute("SELECT payload_json FROM documents WHERE origin='base' AND kind='case_index' ORDER BY ordinal")]
        out['source_manifest']=[json.loads(x[0]) for x in db.execute("SELECT payload_json FROM documents WHERE origin='base' AND kind='source_manifest' ORDER BY ordinal")]
        adj={n['id']:{'outgoing':[],'incoming':[]} for n in out['nodes']}
        for e in out['edges']:
            adj[e['source']]['outgoing'].append(e['id']);adj[e['target']]['incoming'].append(e['id'])
    else:
        adj={n['id']:{'out':[],'in':[]} for n in out['nodes']}
        for e in out['edges']:
            adj[e['source']]['out'].append(e['id']);adj[e['target']]['in'].append(e['id'])
    out['adjacency']=adj
    return out

def run(full_package:Path,review_package:Path,out:Path)->dict:
    if out.exists(): raise FileExistsError(f'Refusing to overwrite {out}')
    out.parent.mkdir(parents=True,exist_ok=True)
    temp=Path(tempfile.mkdtemp(prefix='.flat-build-',dir=out.parent))
    try:
        with zipfile.ZipFile(full_package) as fz,zipfile.ZipFile(review_package) as rz:
            gb=member(fz,'data/graph.json'); sb=member(rz,'semantic_overlay.json'); rb=member(rz,'semantic_reviews.json')
            g=json.loads(gb);s=json.loads(sb);r=json.loads(rb)
            if hashlib.sha256(gb).hexdigest()!=s['base_graph_sha256']:
                raise ValueError('Semantic overlay does not match base graph')
            reviews={x['case_id']:x for x in r['cases']}
            metas={x['case_id']:x for x in g['case_index']}
            if set(metas)!=set(reviews) or len(metas)!=86:raise ValueError('86-case membership mismatch')
            db=sqlite3.connect(temp/'flat_rag.sqlite');db.executescript(SCHEMA)
            # Source parity checked before indexing; no byte normalization.
            rawtotal=msgcount=0
            for m in g['source_manifest']:
                cid=m['case_id'];meta=metas[cid]
                db.execute('INSERT INTO cases VALUES(?,?,?,?)',(cid,meta['repository'],meta['issue_group'],canonical(meta)))
                raw=member(fz,'data/raw_sources/'+cid+'.json')
                h=hashlib.sha256(raw).hexdigest(); gh=hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()
                if (h,gh,len(raw))!=(m['sha256'],m['git_blob_sha1'],m['byte_size']):raise ValueError('Bad raw source '+cid)
                source=json.loads(raw)
                nodes={n['properties']['index']:n['properties']['raw_message'] for n in g['nodes'] if n.get('case_id')==cid and n['type']=='Message'}
                if [nodes[i] for i in range(len(nodes))]!=source['messages']:raise ValueError('Message mismatch '+cid)
                # Root metadata and any future unknown top-level fields are retained.
                sn=next(n for n in g['nodes'] if n['id']=='source:'+cid)
                if sn['properties']['document_fields_other_than_messages']!={k:v for k,v in source.items() if k!='messages'}:
                    raise ValueError('Source metadata mismatch '+cid)
                if reviews[cid]['published_annotation']!=source['metadata']['annotation']:raise ValueError('Review label mismatch')
                if reviews[cid]['published_reward']!=source['metadata']['reward']:raise ValueError('Review reward mismatch')
                for ev in reviews[cid]['evidence']:
                    if digest(source['messages'][ev['message_index']])!=ev['json_value_sha256']:raise ValueError('Review evidence mismatch')
                db.execute('INSERT INTO source_bytes VALUES(?,?,?,?)',(cid,raw,h,gh))
                rawtotal+=len(raw);msgcount+=len(source['messages'])
            for origin,obj,bts in [('base',g,gb),('semantic',s,sb),('review',r,rb)]:
                remove={'nodes','edges','adjacency','case_index','source_manifest'} if origin!='review' else {'cases'}
                header={k:v for k,v in obj.items() if k not in remove}
                db.execute('INSERT INTO artifact_headers VALUES(?,?,?,?)',(origin,canonical(header),digest(obj),hashlib.sha256(bts).hexdigest()))
            counts=Counter();nchunks=0; ftsbatch=[]
            # Export contains every original record payload, not summaries.
            with gzip.open(temp/'flat_documents.jsonl.gz','wt',encoding='utf-8',newline='\n') as docsout:
                def add(origin,kind,sid,ordinal,payload,caseids,definition=None):
                    nonlocal nchunks
                    if not caseids<=set(metas):raise ValueError('Unknown provenance case')
                    did=origin+'|'+kind+'|'+sid
                    text=render(payload,kind,definition)
                    guard=review_guard(reviews[next(iter(caseids))]) if origin in ('semantic','review') and len(caseids)==1 else ''
                    p=canonical(payload);ph=text_digest(p);th=text_digest(text)
                    row=dict(doc_id=did,origin=origin,kind=kind,source_id=sid,ordinal=ordinal,case_ids=sorted(caseids),payload=payload,payload_sha256=ph,text=text,text_sha256=th,guard=guard)
                    docsout.write(canonical(row)+'\n')
                    db.execute('INSERT INTO documents VALUES(?,?,?,?,?,?,?,?,?,?)',(did,origin,kind,sid,ordinal,p,ph,text,th,guard))
                    db.executemany('INSERT INTO document_cases VALUES(?,?)',[(did,c) for c in sorted(caseids)])
                    for part,start,end,body in chunks(text):
                        nchunks+=1
                        db.execute('INSERT INTO chunks VALUES(?,?,?,?,?,?,?,?)',(nchunks,did+'#'+str(part),did,part,start,end,body,text_digest(body)))
                    counts[origin+'.'+kind]+=1
                for origin,obj in [('base',g),('semantic',s)]:
                    own={n['id']:n.get('case_id') for n in obj['nodes']};sc=scopes_for_graph(obj)
                    defs=obj.get('ontology',obj.get('relation_definitions',{}))
                    for i,n in enumerate(obj['nodes']):add(origin,'node',n['id'],i,n,sc[n['id']])
                    for i,e in enumerate(obj['edges']):add(origin,'edge',e['id'],i,e,edge_cases(e,own),defs.get(e.get('relation',e.get('type'))))
                    for i,(key,value) in enumerate(defs.items()):add(origin,'definition',key,i,{'relation':key,'definition':value},set())
                    if origin=='base':
                        for i,x in enumerate(obj['case_index']):add(origin,'case_index',x['case_id'],i,x,{x['case_id']})
                        for i,x in enumerate(obj['source_manifest']):add(origin,'source_manifest',x['case_id'],i,x,{x['case_id']})
                for i,x in enumerate(r['cases']):add('review','review',x['case_id'],i,x,{x['case_id']})
                # Preserve all original corpus policies, flags and aggregate metadata
                # as flat documents too; scope all-corpus aggregates to all cases.
                for i,origin in enumerate(['base','semantic','review']):
                    header=json.loads(db.execute('SELECT header_json FROM artifact_headers WHERE origin=?',(origin,)).fetchone()[0])
                    add('metadata','artifact_header',origin,i,header,set(metas))
            db.execute("INSERT INTO chunk_fts(chunk_fts) VALUES('rebuild')")
            db.commit()
            # Round trip includes all nodes, every edge and regenerated adjacency.
            if rebuild_graph(db,'base')!=g:raise AssertionError('Full graph round trip failed')
            if rebuild_graph(db,'semantic')!=s:raise AssertionError('Semantic graph round trip failed')
            rr=json.loads(db.execute("SELECT header_json FROM artifact_headers WHERE origin='review'").fetchone()[0])
            rr['cases']=[json.loads(x[0]) for x in db.execute("SELECT payload_json FROM documents WHERE origin='review' ORDER BY ordinal")]
            if rr!=r:raise AssertionError('Review round trip failed')
            report={'status':'PASS','cases':len(metas),'unique_issue_groups':len({v['issue_group'] for v in metas.values()}),'repositories':len({v['repository'] for v in metas.values()}),'full_source_messages':msgcount,'original_source_bytes':rawtotal,'source_bytes_verified':86,'source_json_reconstruction_verified':86,'review_records':len(reviews),'review_evidence_messages_verified':sum(len(x['evidence']) for x in reviews.values()),'base_nodes':len(g['nodes']),'base_edges':len(g['edges']),'semantic_nodes':len(s['nodes']),'semantic_edges':len(s['edges']),'proposed_message_relations':s['stats']['explicit_message_to_message_semantic_relations'],'documents':sum(counts.values()),'chunks':nchunks,'record_counts':dict(counts),'base_graph_lossless_roundtrip':True,'semantic_overlay_lossless_roundtrip':True,'semantic_reviews_lossless_roundtrip':True,'source_hashes':{k:hashlib.sha256(v).hexdigest() for k,v in [('base_graph',gb),('semantic_overlay',sb),('semantic_reviews',rb)]},'chunking':{'size_characters':CHUNK_SIZE,'overlap_characters':CHUNK_OVERLAP,'offset_units':'Unicode codepoints; end exclusive'},'retriever':'SQLite FTS5 BM25, lexical OR terms, deterministic tie-break','index_policy':'all graph nodes and all relation statements; no traversal, neighbor expansion, relationship reranking, or LLM query rewriting','advisory':'Artifact parity and integrity, not semantic correctness, retrieval efficacy, or benchmark performance. Corpus headers are indexed as scoped flat documents; adjacency is redundant with the preserved relation records and is rebuilt only by the audit utility.'}
            for k,v in [('parity_report',report),('build_scope',{'excluded_repositories':[],'excluded_issues':[],'excluded_cases':[],'strict_split_index':False})]:
                db.execute('INSERT INTO build_metadata VALUES(?,?)',(k,canonical(v)))
            db.commit();db.execute('PRAGMA optimize')
            if db.execute('PRAGMA integrity_check').fetchone()[0]!='ok':raise ValueError('SQLite integrity failed')
            if db.execute('PRAGMA foreign_key_check').fetchall():raise ValueError('Dangling database references')
            db.close()
            (temp/'parity_report.json').write_text(json.dumps(report,indent=2,ensure_ascii=False)+'\n')
            shutil.move(str(temp),str(out))
            return report
    except Exception:
        shutil.rmtree(temp,ignore_errors=True)
        raise

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--full-package',type=Path,required=True);p.add_argument('--review-package',type=Path,required=True);p.add_argument('--out',type=Path,required=True)
    a=p.parse_args();print(json.dumps(run(a.full_package,a.review_package,a.out),indent=2))
if __name__=='__main__':main()
