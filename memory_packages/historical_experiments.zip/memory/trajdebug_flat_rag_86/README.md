# TrajDebug — same-information flat RAG baseline

## Ready to use

This package contains the **actual populated index**, not just an importer. It is a flat,
lexical RAG baseline for the delivered complete 86-case evidence graph **plus** its first-pass
semantic review. Python 3.10+ and SQLite with FTS5 are required. No download, embedding API,
GPU, model training, database server, or LangGraph installation is required for retrieval.
Use your existing coding model for the generation/solver stage.

```bash
python flat_rag.py stats
python flat_rag.py search "SIGSEGV legacy test" --limit 5
python flat_rag.py context "SIGSEGV legacy test" --top-k 8 --max-chars 24000
python flat_rag.py read "base|node|C018:message:92" --max-chars 6000
```

Run commands from this folder. `context` returns a JSON evidence bundle that can be supplied to
the same frozen coding agent used in the graph condition. `search` returns previews; `read`
paginates an explicitly requested document. Nothing follows an edge automatically.

## Identical information, different retrieval

| Preserved input | Count |
|---|---:|
| Full original failed attempts | 86 |
| Full original messages, including later recovery | 10,249 |
| Issue groups / repositories | 57 / 7 |
| Original evidence-graph nodes / edges | 23,541 / 44,699 |
| Semantic-overlay nodes / edges | 2,009 / 2,107 |
| Complete first-pass review records | 86 |
| Proposed message-to-message semantic relations within the overlay | 50 |
| Flat documents / searchable chunks | 72,676 / 74,541 |

These are **records**, not 72,676 independent lessons. Repeated descriptions, source messages,
parsed tool invocations, annotations, and relation facts are retained because they also exist
in the source graphs. No new summaries, diagnoses, confidence scores, or causal claims were
created for this baseline. All 24 unresolved reviews and the nine null original error-category
labels remain present. Review findings retain their provisional status.

An original graph edge such as `A --STATED_MOTIVATES--> B` becomes an ordinary searchable
relation document, including its exact original payload, relation definition, evidence
references and evidence status. The flat retriever does **not** interpret the edge as a link
that it should follow. A model can still reason about a relationship it reads; that is expected.

The flat corpus preserves **all 46,806 original relation records** (44,699 base + 2,107 overlay).
Of these, 50 are the review's proposed message-to-message semantic relationships; the rest
include evidence citations, identity links, chronology, and other structural relations.
Removing those relation facts from the flat baseline would change the available information,
not just the retrieval method.

## What “identical” was checked to mean

`verification/full_parity_verification.json` records completed checks on the real data:

* All 86 original files are stored byte-for-byte inside the SQLite `source_bytes` table;
  their 19,844,129 bytes match the complete source package and its source hashes.
* Every original JSON message and metadata field can be reconstructed from the flat records.
* The entire base graph, semantic overlay, and review JSON reconstruct to equal parsed JSON
  objects, including ordered arrays. Original graph adjacency is deterministically regenerated
  **only for verification** from the preserved relation records.
* Every document's original payload, complete rendered text and every indexed character
  window are verified. There are no missing document suffixes.
* 85,395 source evidence-pointer instances and 1,197 review-cited messages were checked.
  Repeated references are not independent evidence.
* Compressed JSONL records agree with the database. All 47 regression tests passed.

JSON whitespace and object-key order in flat payload serialization are not promised to match
old JSON files byte-for-byte. Values and array order do match. Original trajectory bytes are
separately preserved exactly. The original base graph uses insertion-order JSON hashing for
some evidence values, whereas the semantic review uses sorted-key canonicalization. The
verifier respects both conventions without changing their recorded hashes.

The two source graphs have different creation stages. For example, older base-build metadata
can say semantic review is pending while the separate overlay contains the later review.
Those original version-scoped statements are retained, not silently rewritten.

## Files

| File | Role |
|---|---|
| `data/flat_rag.sqlite` | Populated, self-contained flat documents, chunks, FTS5 index and original source bytes. |
| `data/flat_documents.jsonl.gz` | Portable lossless document export, one JSON object per line after decompression. |
| `data/parity_report.json` | Corpus counts, input hashes, build settings and equality checks. |
| `flat_rag.py` | Read-only search, direct document retrieval, bounded context assembly and generation callback. |
| `flat_core.py` | Common lossless renderer, chunker and copied caveat wrapper for BOTH experimental arms. |
| `make_split.py` | Builds an allowed-only database and rebuilds the search index before evaluation. |
| `build_flat_rag.py` | Rebuilds this corpus from the two original delivered packages, without network calls. |
| `verify_flat_rag.py` | Verifies every record, raw file, pointer, chunk and graph round trip. |
| `agent_tools.json` | Provider-neutral tool contracts for flat search and direct reading. |
| `AGENT_GUIDE.md` | Integration, pagination and safety boundaries. |
| `EXPERIMENT_PROTOCOL.md` | How to keep the graph/flat comparison controlled. |
| `examples/` | Retrieval outputs generated with the populated corpus; not benchmark results. |
| `source_notices/` | Original dataset notices and preserved source-artifact documentation. |

Corpus metadata, node properties, relation meanings, provenance, review caveats, and source
identities are included in flat documents. Index-layout adjacency is not searched as a separate
document because it is redundant with the preserved edges. Complete artifact headers also
remain available for audit. The production reader has no adjacency, neighbor, path, or
cross-case graph-expansion method, and its database has no graph-edge/adjacency tables.

## Retrieval behavior

The index uses **BM25 keyword retrieval, not neural embeddings**. This matches the retrieval
family used in the existing graph/review readers; it avoids changing both retriever family
and graph use at once. Documents are deterministically divided into 6,000-Unicode-character
chunks with 400-character overlap. These sizes are experimental settings, not tuned findings.
No text is discarded. Query words are OR-matched, up to 32 unique terms; no model rewrites the
query. Lower SQLite BM25 scores rank first, with document/part IDs breaking ties.

Default retrieval searches all available records. Optional `--origin review` restricts search
to the 86 review documents, but that is a **different predeclared retrieval condition**, not
the default full-corpus baseline. Do not enable it only in one arm.

Semantic document chunks carry the original case review's caveat and status as a copied
wrapper. This protects against showing an isolated candidate lesson without its uncertainty.
Use the same `flat_core.review_guard` wrapper in the graph arm; it is additional formatting
of existing facts, not a new model-generated interpretation. Identical wrappers are charged
to the context budget in both arms.

`--max-chars` caps the retrieved context string only. It is not a token limit or a whole-prompt
limit. The Python API supports an actual model-token limit via an injected `count_tokens`
callback; reserve separate space for the current issue, system prompt, tools, and generation.
If a chunk is displayed partially, its offsets and continuation are returned. Stored text
always remains complete.

## Generation with the same model

```python
from flat_rag import FlatRAG

# existing_generate(messages) must call the SAME model/configuration used in the graph arm.
# Keep its sampling settings, tool access and solver budget unchanged.
with FlatRAG() as memory:
    result = memory.rag(
        "Current issue or debugging observation",
        generate=existing_generate,
        top_k=8,
        max_chars=24000,
    )
    answer = result["answer"]
    retrieval_log = result["retrieval"]
```

The callback tests used a stub, not a real model. No API key or provider is embedded in this
package, no generation model has been run against the corpus, and no SWE-bench results are
claimed. For an existing coding harness, usually inject `memory.retrieve(...)["context"]`
into the same memory slot rather than replacing the harness with `rag()`.

## Holdout safety

Split by issue group at minimum; several models attempted the same issue. Prefer holding out
repositories when appropriate. A strict split should be made **before indexing**, so excluded
cases influence neither retrieved content nor BM25 document-frequency statistics:

```bash
python make_split.py --exclude-repository qutebrowser/qutebrowser --out splits/train.sqlite
python flat_rag.py --db splits/train.sqlite search "SIGSEGV legacy test"
```

The split builder removes excluded source bytes and documents, including shared records
with any excluded contributor, then rebuilds FTS. The full parity corpus is unchanged; a
subset database intentionally cannot reconstruct the full 86-case graphs.

Runtime filters are also supported for convenient checks:

```bash
python flat_rag.py --exclude-repository qutebrowser/qutebrowser search "SIGSEGV"
python flat_rag.py --exclude-case C018 read "review|review|C018"
```

They block excluded results and direct reads, but do **not** recompute corpus statistics.
They are not a substitute for the pre-index split in a strict benchmark experiment. The
source-origin filters do not scrub every textual mention of a held-out project in other
cases, and issue grouping does not detect all near-duplicate or translated tasks.

## Rebuild / verify

```bash
python -m unittest discover -s tests -v
python verify_flat_rag.py --out verification/recheck.json
python build_flat_rag.py \
  --full-package /path/to/trajdebug_full_86_COMPLETE.zip \
  --review-package /path/to/trajdebug_semantic_review_86_FIRST_PASS.zip \
  --out rebuilt_data
```

Integrity verification and rebuilding reject overwriting a new build output directory.
Original source files and previous user packages are never modified by ingestion. Indexing
and reading do not execute any commands contained in the data.

## Scientific and safety limits

This is a **same-information retrieval baseline**, not validation of the 86 explanations or
of any causal claim. The existing 119 source messages with clipping markers stay clipped
exactly as released. The existing single-AI review remains single-AI and annotation-guided.
No missing observations, final filesystem snapshots, successful counterfactuals or independent
judge ratings are invented.

Untrusted source messages can contain instructions or commands. They must be treated as data;
a warning is not a complete prompt-injection defense. Do not give a benchmark agent unrestricted
filesystem/SQLite access to held-out data or administrative reconstruction tools. Enforce the
retrieval boundary in its harness and maintain the same boundary in the graph condition.

**Same corpus does not automatically mean a controlled graph-vs-flat experiment.** The old
graph readers have different chunking, hypothesis visibility, evidence-loading, and selection
defaults. Align them with the shared renderer/index and experimental settings in
`EXPERIMENT_PROTOCOL.md` before attributing any difference to graph traversal.
