# Controlled flat-versus-graph retrieval experiment

## Hypothesis

Does explicitly following evidence/semantic relationships select more useful context than
flat ranking of the **same historical facts and relation statements**?

No result has been measured yet. This package implements the flat condition and shared
representation; it does not rerun or validate the graph condition.

## Shared inputs

Use the delivered full source graph plus the semantic overlay and all original review
records. `data/parity_report.json` identifies exact input hashes. Keep source scope, unresolved
cases, repaired mistakes, original annotation nulls and provisional labels the same.

Use `flat_core.render`, `flat_core.chunks`, and `flat_core.review_guard` in both conditions.
Treat relation records as facts in both. The flat arm can retrieve them by text; it never
follows their endpoints. The graph arm may use them to expand its candidate selection.
A model inferring a connection from retrieved text is not a graph traversal operation.

For the cleanest test, both arms start with the same BM25 query and candidate/chunk index.
The graph arm may replace some flat candidates with connected records under a predeclared
expansion policy; use the same final representation and budget. Do not give it a larger
initial candidate pool, extra LLM calls, more metadata, or free evidence access unless the
experiment explicitly studies that entire system change.

## Frozen settings

| Setting | Keep identical / declare in advance |
|---|---|
| Solver | Model, version, sampling parameters, tool permissions and repair budget. |
| Build split | Same issue/repository exclusion and allowed source-origin memberships. |
| Ranker | SQLite FTS5 BM25 over the same chunk text; both use identical query terms. |
| Chunking | 6,000 Unicode characters, 400-character overlap; same renderer. |
| Candidate budget | Same initial top-k and total examined candidates, or explicitly accounted cost. |
| Context | Same exact tokenizer and retrieved-context token limit; count caveat wrappers. |
| Memory calls | Same opportunities and maximum calls during repair. |
| Generation | Same coding harness and prompt slots; no condition-specific coaching. |
| Extra retrieval | Disable in both for one-shot retrieval, or charge every read/search in both. |
| Hypotheses | Same visibility for legacy/provisional relations; source flags remain unchanged. |

The prior base graph reader hid some hypothesis links by default. This flat index preserves
all original relation statements. Enabling different visibility by arm is not a fair control:
either use the complete statements in both or implement the same preregistered exclusion.

BM25 is intentionally used rather than silently introducing embedding-based RAG. Testing
semantic embeddings later is a separate factor; apply the same encoder, retrieval units
and scoring to both arms. No embedding model/weights or embedding index is included here.

## Holdouts

Create the allowed-only index with `make_split.py` before evaluation. Runtime filtering
alone removes hits but not excluded-corpus effects on document frequencies. The split
builder removes excluded bytes/documents and rebuilds FTS; use that exact corpus for graph
construction too. Shared records are removed if any contributing case is excluded, without
rewriting their original claims.

A runtime filter is not an access-control system. Expose only the allowed retriever to the
solver. Do not expose the whole source ZIP, full JSON, full DB, statistics, parity verifier,
or reconstruction utility. Review which repositories/issues overlap an intended benchmark,
and check near-duplicates separately. The corpus is SWE-Bench Pro-derived; mapping it to a
Verified evaluation does not automatically make those problems disjoint.

## Report

Report resolved tasks and paired per-task outcomes, repeated-run uncertainty when affordable,
solver tokens and tool calls, retrieval/embedding costs if present, and actual memory-context
tokens. Log returned record IDs, ranking scores, original source scopes, truncation offsets,
selected relation statements and allowed graph expansions. Scores are relevance ranks, not
confidence in a failure lesson.

For error propagation, separately score use of unvalidated claims, attribution to repaired
mistakes, and preservation of counterevidence. The existing review is not independent gold
truth. Audit outcome disagreements rather than assuming the graph or review is correct.

The “all failed” source sample cannot estimate population-wide failure prevalence. Do not
claim a causal benefit of graph memory before this controlled evaluation has been run.
