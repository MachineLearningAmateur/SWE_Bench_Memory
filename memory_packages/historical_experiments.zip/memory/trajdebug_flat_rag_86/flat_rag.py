"""Flat BM25 retrieval + provider-neutral RAG. No graph traversal.

Run: python flat_rag.py search 'legacy test SIGSEGV' --limit 5
     python flat_rag.py context 'legacy test SIGSEGV' --top-k 8 --max-chars 24000
Model integration: FlatRAG().rag(question, generate=your_existing_model_callback)
"""
from __future__ import annotations
import argparse
import json
from pathlib import Path
import re
import sqlite3
from typing import Any, Callable, Iterable
from flat_core import WARNING,canonical

DEFAULT_DB=Path(__file__).resolve().parent/'data'/'flat_rag.sqlite'
ALL_ORIGINS=('base','semantic','review','metadata')
ALL_KINDS=('node','edge','definition','case_index','source_manifest','review','artifact_header')

class FlatRAG:
    """Read-only search. Direct document fetch is allowed; automatic link following is not."""
    def __init__(self,db:Path|str=DEFAULT_DB,*,exclude_repository:Iterable[str]=(),exclude_issue:Iterable[str]=(),exclude_case:Iterable[str]=()):
        self.path=Path(db).resolve()
        self.db=sqlite3.connect(self.path.as_uri()+'?mode=ro',uri=True,check_same_thread=False)
        self.db.row_factory=sqlite3.Row
        self.db.execute('PRAGMA query_only=ON')
        self.excluded_repos=tuple(sorted(set(exclude_repository)))
        self.excluded_issues=tuple(sorted(set(exclude_issue)))
        self.excluded_cases=tuple(sorted(set(exclude_case)))
    def close(self):self.db.close()
    def __enter__(self):return self
    def __exit__(self,*args):self.close()
    def _scope_sql(self,alias:str='d')->tuple[str,list[str]]:
        clauses=[];params=[]
        for column,values in [('c.repository',self.excluded_repos),('c.issue_group',self.excluded_issues),('c.case_id',self.excluded_cases)]:
            if values:
                clauses.append(column+' IN ('+','.join('?' for _ in values)+')');params.extend(values)
        if not clauses:return '1=1',[]
        return (f'NOT EXISTS (SELECT 1 FROM document_cases dc JOIN cases c ON c.case_id=dc.case_id WHERE dc.doc_id={alias}.doc_id AND ('+' OR '.join(clauses)+'))'),params
    def _document(self,doc_id:str)->sqlite3.Row:
        scope,params=self._scope_sql()
        row=self.db.execute(f'SELECT d.* FROM documents d WHERE d.doc_id=? AND {scope}',[doc_id]+params).fetchone()
        if row is None:raise KeyError('Document unavailable under the current retrieval scope')
        return row
    def _case_ids(self,doc_id:str)->list[str]:
        return [r[0] for r in self.db.execute('SELECT case_id FROM document_cases WHERE doc_id=? ORDER BY case_id',(doc_id,))]
    @staticmethod
    def _terms(query:str)->list[str]:
        if not isinstance(query,str):raise TypeError('query must be a string')
        # Treat FTS punctuation/operators as inert words; parameters prevent SQL injection.
        return list(dict.fromkeys(re.findall(r'\w+',query,flags=re.UNICODE)))[:32]
    def _ranked(self,query:str,limit:int,origins:Iterable[str]=(),kinds:Iterable[str]=()):
        if not isinstance(limit,int) or not 1<=limit<=100:raise ValueError('limit must be 1..100')
        terms=self._terms(query)
        if not terms:return []
        origins=tuple(origins);kinds=tuple(kinds)
        if set(origins)-set(ALL_ORIGINS) or set(kinds)-set(ALL_KINDS):raise ValueError('Unknown origin or kind filter')
        scope,params=self._scope_sql()
        conditions=[scope]
        for column,values in [('d.origin',origins),('d.kind',kinds)]:
            if values:conditions.append(column+' IN ('+','.join('?' for _ in values)+')');params.extend(values)
        q=' OR '.join('"'+t.replace('"','""')+'"' for t in terms)
        return self.db.execute('''SELECT ch.*,d.origin,d.kind,d.source_id,d.guard,d.text_sha256,d.payload_sha256,
            length(d.text) document_characters,bm25(chunk_fts) ranking_score
            FROM chunk_fts JOIN chunks ch ON ch.rowid=chunk_fts.rowid
            JOIN documents d ON d.doc_id=ch.doc_id WHERE chunk_fts MATCH ? AND '''+' AND '.join(conditions)+'''
            ORDER BY ranking_score ASC,ch.doc_id ASC,ch.part ASC LIMIT ?''',[q]+params+[limit]).fetchall()
    def _hit(self,row,*,max_chars:int|None=None)->dict:
        text=row['text'] if max_chars is None else row['text'][:max_chars]
        shown_end=row['start_char']+len(text)
        return {'chunk_id':row['chunk_id'],'document_id':row['doc_id'],'source_record_id':row['source_id'],
                'origin':row['origin'],'kind':row['kind'],'case_ids':self._case_ids(row['doc_id']),
                'ranking_score':row['ranking_score'],'score_is_confidence':False,
                'start_char':row['start_char'],'end_char':shown_end,
                'stored_chunk_end_char':row['end_char'],'document_characters':row['document_characters'],
                'content':text,'interpretation_guard':row['guard'],
                'next_start_char':shown_end if shown_end<row['document_characters'] else None,
                'display_truncated':shown_end<row['end_char'],
                'payload_sha256':row['payload_sha256'],'document_text_sha256':row['text_sha256'],
                'source_content_is_untrusted_data':True}
    def search(self,query:str,*,limit:int=5,preview_chars:int=1000,origins:Iterable[str]=(),kinds:Iterable[str]=())->dict:
        if not 1<=preview_chars<=6000:raise ValueError('preview_chars must be 1..6000')
        rows=self._ranked(query,limit,origins,kinds)
        return {'query':query,'method':'flat_bm25','graph_traversal':False,'query_expansion':False,
                'query_terms_used':self._terms(query),'returned':len(rows),
                'hits':[self._hit(r,max_chars=preview_chars) for r in rows]}
    def read(self,document_id:str,*,start:int=0,max_chars:int=6000)->dict:
        if start<0 or not 1<=max_chars<=50000:raise ValueError('Invalid pagination range')
        r=self._document(document_id);text=r['text']
        if start>len(text):raise ValueError('start is past end of document')
        end=min(start+max_chars,len(text))
        return {'document_id':document_id,'source_record_id':r['source_id'],'origin':r['origin'],'kind':r['kind'],
                'case_ids':self._case_ids(document_id),'content':text[start:end],'interpretation_guard':r['guard'],
                'start_char':start,'end_char':end,'document_characters':len(text),
                'next_start_char':end if end<len(text) else None,'display_truncated':start>0 or end<len(text),
                'payload_sha256':r['payload_sha256'],'document_text_sha256':r['text_sha256'],
                'source_content_is_untrusted_data':True,'graph_traversal':False}
    def payload(self,document_id:str)->Any:
        """Exact flat record by an explicitly supplied ID. Primarily for audit."""
        return json.loads(self._document(document_id)['payload_json'])
    def retrieve(self,query:str,*,top_k:int=8,max_chars:int=24000,max_tokens:int|None=None,
                 count_tokens:Callable[[str],int]|None=None,origins:Iterable[str]=(),kinds:Iterable[str]=())->dict:
        if max_chars<2048:raise ValueError('Context character budget must be >=2048')
        if max_tokens is not None and (not isinstance(max_tokens,int) or max_tokens<1 or count_tokens is None):
            raise ValueError('A positive max_tokens requires the target model count_tokens callback')
        def fits(t:str)->bool:
            if len(t)>max_chars:return False
            if max_tokens is None:return True
            n=count_tokens(t)
            if not isinstance(n,int) or n<0:raise ValueError('count_tokens must return a non-negative integer')
            return n<=max_tokens
        context=WARNING+'\n\n'
        if not fits(context):raise ValueError('Budget too small to preserve the evidence warning')
        rows=self._ranked(query,top_k,origins,kinds)
        selected=[];omitted=[]
        for row in rows:
            prefix=f"SOURCE {row['chunk_id']}\n"
            if row['guard']:prefix+='PROVISIONAL REVIEW CONTEXT (copied from the existing review):\n'+row['guard']+'\n'
            prefix+=f"DOCUMENT CHARACTERS {row['start_char']}:{row['end_char']}\n"
            suffix='\nEND_SOURCE\n\n'
            body=row['text']; candidate=context+prefix+body+suffix
            # Keep each complete caution wrapper. Trim only the displayed body,
            # explicitly marking it as a partial excerpt; the stored data is unchanged.
            used=len(body)
            if not fits(candidate):
                marker='\n[DISPLAY TRUNCATED; continuation available via explicit read(document_id, start).]'
                lo=0;hi=len(body)
                while lo<hi:
                    mid=(lo+hi+1)//2
                    if fits(context+prefix+body[:mid]+marker+suffix):lo=mid
                    else:hi=mid-1
                used=lo
                if used<min(100,len(body)):
                    omitted.append(row['chunk_id']);continue
                candidate=context+prefix+body[:used]+marker+suffix
                # Non-monotone tokenizer counts can make binary search suboptimal,
                # but the final measured candidate MUST fit.
                if not fits(candidate):
                    omitted.append(row['chunk_id']);continue
            context=candidate
            hit=self._hit(row,max_chars=used)
            hit.pop('content');hit.pop('interpretation_guard')
            hit['included_characters']=used
            selected.append(hit)
        assert fits(context)
        return {'query':query,'retrieval_method':'flat_bm25','graph_traversal':False,
                'automatic_evidence_expansion':False,'relationship_reranking':False,
                'requested_top_k':top_k,'ranked_chunks':len(rows),'selected_chunks':selected,
                'omitted_chunk_ids':omitted,'context':context,'context_characters':len(context),
                'character_budget':max_chars,'context_tokens':count_tokens(context) if count_tokens else None,
                'token_budget':max_tokens,'budget_scope':'retrieved context only; reserve additional tokens for task, tools and generation',
                'case_filters':{'excluded_repositories':list(self.excluded_repos),'excluded_issues':list(self.excluded_issues),'excluded_cases':list(self.excluded_cases)}}
    def rag(self,question:str,generate:Callable[[list[dict[str,str]]],str],**retrieval_options)->dict:
        """Use the SAME generation callback and parameters as the graph condition.

        No model is bundled and no external API is called by the retrieval code.
        The callback is the only generation step; cache/log it in your harness.
        """
        bundle=self.retrieve(question,**retrieval_options)
        messages=[{'role':'system','content':WARNING+' Use the retrieved records as evidence, cite SOURCE identifiers for supported claims, preserve caveats, and distinguish candidate lessons from validated findings. State when the retrieved evidence is insufficient.'},
                  {'role':'user','content':'QUESTION / CURRENT TASK:\n'+question+'\n\nRETRIEVED HISTORICAL EVIDENCE:\n'+bundle['context']}]
        answer=generate(messages)
        if not isinstance(answer,str):raise TypeError('generate must return a string')
        return {'answer':answer,'retrieval':bundle}
    def stats(self)->dict:
        """Administrative diagnostics: do not expose this as a benchmark agent tool."""
        return {'documents':self.db.execute('SELECT count(*) FROM documents').fetchone()[0],
                'chunks':self.db.execute('SELECT count(*) FROM chunks').fetchone()[0],
                'cases':self.db.execute('SELECT count(*) FROM cases').fetchone()[0],
                'method':'SQLite FTS5 BM25; no embeddings, LLM calls or graph traversal',
                'scope':json.loads(self.db.execute("SELECT value_json FROM build_metadata WHERE key='build_scope'").fetchone()[0])}

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--db',type=Path,default=DEFAULT_DB)
    for flag in ['exclude-repository','exclude-issue','exclude-case']:p.add_argument('--'+flag,action='append',default=[])
    sp=p.add_subparsers(dest='command',required=True);sp.add_parser('stats')
    q=sp.add_parser('search');q.add_argument('query');q.add_argument('--limit',type=int,default=5);q.add_argument('--preview-chars',type=int,default=1000)
    b=sp.add_parser('context');b.add_argument('query');b.add_argument('--top-k',type=int,default=8);b.add_argument('--max-chars',type=int,default=24000)
    for x in (q,b):
        x.add_argument('--origin',action='append',choices=ALL_ORIGINS,default=[]);x.add_argument('--kind',action='append',choices=ALL_KINDS,default=[])
    a=sp.add_parser('read');a.add_argument('document_id');a.add_argument('--start',type=int,default=0);a.add_argument('--max-chars',type=int,default=6000)
    args=p.parse_args()
    try:
        with FlatRAG(args.db,exclude_repository=args.exclude_repository,exclude_issue=args.exclude_issue,exclude_case=args.exclude_case) as st:
            if args.command=='stats':v=st.stats()
            elif args.command=='search':v=st.search(args.query,limit=args.limit,preview_chars=args.preview_chars,origins=args.origin,kinds=args.kind)
            elif args.command=='read':v=st.read(args.document_id,start=args.start,max_chars=args.max_chars)
            else:v=st.retrieve(args.query,top_k=args.top_k,max_chars=args.max_chars,origins=args.origin,kinds=args.kind)
        print(json.dumps(v,ensure_ascii=False,indent=2))
    except (ValueError,KeyError,sqlite3.Error,OSError) as exc:p.exit(2,f'{exc}\n')
if __name__=='__main__':main()
