"""Real-corpus regression tests plus deterministic small unit tests.

No benchmark tasks, source commands, or actual model generations are executed.
"""
import gzip
import hashlib
import inspect
import json
from pathlib import Path
import sqlite3
import sys
import tempfile
import unittest
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from flat_core import canonical,digest,render,chunks,WARNING,review_guard
from flat_rag import FlatRAG,DEFAULT_DB
from make_split import make_split

class TestChunking(unittest.TestCase):
    def test_unicode_exact(self):
        text='東京\nα🚂'*3000;out=list(chunks(text,400,30));end=0
        for i,s,e,v in out:self.assertEqual(v,text[s:e]);self.assertLessEqual(s,end);end=e
        self.assertEqual(end,len(text))
    def test_empty(self):self.assertEqual(list(chunks('')),[(0,0,0,'')])
    def test_size_validation(self):
        with self.assertRaises(ValueError):list(chunks('a',100,0))
    def test_overlap_validation(self):
        with self.assertRaises(ValueError):list(chunks('a',256,256))
    def test_literal_newline(self):self.assertIn('a\nb',render({'a':'a\nb'},'node'))
    def test_null_and_false_retained(self):
        text=render({'x':None,'y':False},'node');self.assertIn('null',text);self.assertIn('false',text)
    def test_relation_statement(self):
        s=render({'source':'A','target':'B','type':'STATED_MOTIVATES','is_causal_claim':False},'edge','Stated rationale, not proof.')
        self.assertIn('A --STATED_MOTIVATES--> B',s);self.assertIn('not proof',s)
    def test_unknown_fields_preserved(self):self.assertIn('future',render({'future':{'unknown':['α',{}]}},'node'))

class TestRealCorpus(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.store=FlatRAG();cls.db=cls.store.db
    @classmethod
    def tearDownClass(cls):cls.store.close()
    def test_86_cases(self):self.assertEqual(self.store.stats()['cases'],86)
    def test_all_messages(self):
        rows=self.db.execute("SELECT payload_json FROM documents WHERE origin='base' AND kind='node'")
        self.assertEqual(sum(json.loads(r[0])['type']=='Message' for r in rows),10249)
    def test_all_base_edges(self):self.assertEqual(self.db.execute("SELECT count(*) FROM documents WHERE origin='base' AND kind='edge'").fetchone()[0],44699)
    def test_all_semantic_edges(self):self.assertEqual(self.db.execute("SELECT count(*) FROM documents WHERE origin='semantic' AND kind='edge'").fetchone()[0],2107)
    def test_all_review_cards(self):self.assertEqual(self.db.execute("SELECT count(*) FROM documents WHERE origin='review'").fetchone()[0],86)
    def test_all_reviews_unvalidated(self):
        for r in self.db.execute("SELECT payload_json FROM documents WHERE origin='review'"):
            p=json.loads(r[0]);self.assertFalse(p['terminal_cause_validated']);self.assertFalse(p['candidate_lesson_validated'])
    def test_raw_bytes_86(self):self.assertEqual(self.db.execute('SELECT count(*) FROM source_bytes').fetchone()[0],86)
    def test_raw_hashes_all(self):
        for r in self.db.execute('SELECT * FROM source_bytes'):self.assertEqual(hashlib.sha256(r['data']).hexdigest(),r['sha256'])
    def test_read_only(self):
        with self.assertRaises(sqlite3.OperationalError):self.db.execute("DELETE FROM chunks")
    def test_no_adjacency_tables(self):
        tables={r[0] for r in self.db.execute("SELECT name FROM sqlite_master WHERE type='table'")}
        self.assertFalse({'edges','adjacency','neighbors'} & tables)
    def test_no_traversal_api(self):
        self.assertFalse(hasattr(self.store,'neighbors'));self.assertFalse(hasattr(self.store,'related'))
    def test_search_deterministic(self):
        a=self.store.search('SIGSEGV legacy test',limit=6);b=self.store.search('SIGSEGV legacy test',limit=6);self.assertEqual(a,b)
    def test_known_example_retrieved(self):
        ids=[x['case_ids'] for x in self.store.search('SIGSEGV legacy test',limit=5)['hits']]
        self.assertIn(['C018'],ids)
    def test_empty_query(self):self.assertEqual(self.store.search('!!!')['hits'],[])
    def test_missing_term(self):self.assertEqual(self.store.search('zzunfindableQ9283zz')['hits'],[])
    def test_sql_like_query_safe(self):self.store.search('" OR 1=1; DROP TABLE documents --');self.assertEqual(self.store.stats()['cases'],86)
    def test_explicit_filters(self):
        r=self.store.search('SIGSEGV',origins=['review'],limit=3)
        self.assertTrue(r['hits']);self.assertTrue(all(x['origin']=='review' for x in r['hits']))
    def test_bad_filter_rejected(self):
        with self.assertRaises(ValueError):self.store.search('test',origins=['unknown'])
    def test_continuation_exact(self):
        did='base|node|C018:message:89';text=self.db.execute('SELECT text FROM documents WHERE doc_id=?',(did,)).fetchone()[0]
        a=self.store.read(did,max_chars=170);b=self.store.read(did,start=a['next_start_char'],max_chars=170)
        self.assertEqual(a['content']+b['content'],text[:340])
    def test_missing_document(self):
        with self.assertRaises(KeyError):self.store.read('notfound')
    def test_invalid_pagination(self):
        with self.assertRaises(ValueError):self.store.read('base|node|C018:message:89',start=-1)
    def test_guard_repeats_caveat(self):
        d=self.store.read('semantic|node|sem:C018:lesson',max_chars=20)
        self.assertIn('counterevidence_and_limits',d['interpretation_guard']);self.assertIn('terminal_cause_validated: false',d['interpretation_guard'])
    def test_char_budget(self):
        r=self.store.retrieve('SIGSEGV tests',top_k=15,max_chars=4096)
        self.assertLessEqual(len(r['context']),4096);self.assertEqual(r['context_characters'],len(r['context']))
    def test_char_budget_warning_kept(self):self.assertIn(WARNING,self.store.retrieve('test',max_chars=2048)['context'])
    def test_tokens_need_callback(self):
        with self.assertRaises(ValueError):self.store.retrieve('test',max_tokens=100)
    def test_exact_custom_token_budget(self):
        # A fake deterministic counter tests callback enforcement, not a real model tokenizer.
        r=self.store.retrieve('SIGSEGV tests',max_chars=10000,max_tokens=1200,count_tokens=lambda t:len(t.encode('utf-8')))
        self.assertLessEqual(len(r['context'].encode('utf-8')),1200);self.assertEqual(r['context_tokens'],len(r['context'].encode('utf-8')))
    def test_generation_callback(self):
        calls=[]
        def stub(messages):calls.append(messages);return 'MOCK GENERATION; no model invoked'
        r=self.store.rag('SIGSEGV legacy test',generate=stub,top_k=3,max_chars=6000)
        self.assertEqual(len(calls),1);self.assertIn('MOCK',r['answer']);self.assertIn(WARNING,calls[0][0]['content'])
    def test_null_original_annotation(self):
        count=0
        for cid, in self.db.execute('SELECT case_id FROM cases'):
            d=json.loads(self.db.execute('SELECT data FROM source_bytes WHERE case_id=?',(cid,)).fetchone()[0]);count+=d['metadata']['annotation']['critical_error_type'] is None
        self.assertEqual(count,9)
    def test_repaired_c074_preserved(self):
        r=self.store.payload('review|review|C074')
        self.assertIn('repair',r['lifecycle_status'])
        m=self.store.payload('base|node|C074:message:82');self.assertIn('DeviceDetails',m['properties']['raw_message']['content'])
    def test_unresolved_24_retained(self):
        count=sum(json.loads(r[0])['evidence_grade']=='unresolved' for r in self.db.execute("SELECT payload_json FROM documents WHERE origin='review'"));self.assertEqual(count,24)

class TestFiltering(unittest.TestCase):
    def test_repo_search_excluded(self):
        with FlatRAG(exclude_repository=['qutebrowser/qutebrowser']) as s:
            for h in s.search('SIGSEGV',limit=50)['hits']:
                for c in h['case_ids']:
                    repo=s.db.execute('SELECT repository FROM cases WHERE case_id=?',(c,)).fetchone()[0];self.assertNotEqual(repo,'qutebrowser/qutebrowser')
    def test_repo_direct_read_excluded(self):
        with FlatRAG(exclude_repository=['qutebrowser/qutebrowser']) as s:
            with self.assertRaises(KeyError):s.read('base|node|C018:message:89')
    def test_review_direct_read_excluded(self):
        with FlatRAG(exclude_case=['C018']) as s:
            with self.assertRaises(KeyError):s.read('review|review|C018')
    def test_edge_scope_excluded(self):
        with FlatRAG(exclude_case=['C018']) as s:
            did=s.db.execute("SELECT d.doc_id FROM documents d JOIN document_cases dc ON dc.doc_id=d.doc_id WHERE dc.case_id='C018' AND d.origin='base' AND d.kind='edge' LIMIT 1").fetchone()[0]
            with self.assertRaises(KeyError):s.payload(did)
    def test_issue_all_models_excluded(self):
        with FlatRAG() as s:issue=s.db.execute("SELECT issue_group FROM cases WHERE case_id='C018'").fetchone()[0]
        with FlatRAG(exclude_issue=[issue]) as s:
            for cid, in s.db.execute('SELECT case_id FROM cases WHERE issue_group=?',(issue,)):
                with self.assertRaises(KeyError):s.payload('review|review|'+cid)
    def test_shared_record_fails_closed(self):
        with FlatRAG(exclude_case=['C018']) as s:
            with self.assertRaises(KeyError):s.payload('semantic|node|sem:shared:Repository:qutebrowser/qutebrowser')
    def test_strict_split_removes_documents_and_idf(self):
        with tempfile.TemporaryDirectory() as tmp:
            out=Path(tmp)/'allowed.sqlite'
            r=make_split(DEFAULT_DB,out,exclude_repository=['qutebrowser/qutebrowser'])
            self.assertTrue(r['strict_split_index']);self.assertLess(r['remaining_cases'],86)
            with FlatRAG(out) as s:
                self.assertEqual(s.db.execute("SELECT count(*) FROM cases WHERE repository='qutebrowser/qutebrowser'").fetchone()[0],0)
                self.assertEqual(s.db.execute("SELECT count(*) FROM source_bytes WHERE case_id='C018'").fetchone()[0],0)
                with self.assertRaises(KeyError):s.payload('review|review|C018')
                self.assertEqual(s.db.execute('SELECT count(*) FROM chunks').fetchone()[0],s.db.execute('SELECT count(*) FROM chunk_fts').fetchone()[0])
                self.assertFalse(s.db.execute('PRAGMA foreign_key_check').fetchall())
    def test_split_noop_rejected(self):
        with tempfile.TemporaryDirectory() as tmp:
            with self.assertRaises(ValueError):make_split(DEFAULT_DB,Path(tmp)/'x.sqlite',exclude_case=['NO_CASE'])
    def test_split_no_overwrite(self):
        with tempfile.TemporaryDirectory() as tmp:
            p=Path(tmp)/'x.sqlite';p.write_text('keep')
            with self.assertRaises(FileExistsError):make_split(DEFAULT_DB,p,exclude_case=['C018'])
            self.assertEqual(p.read_text(),'keep')

if __name__=='__main__':unittest.main()
