# TrajDebug — complete 86-trajectory evidence-linked graph

## Status: completed on the real corpus

This package **contains all 86 complete released English SWE-Bench Pro trajectory files**, not only an importer or selected excerpts. It was built from the supplied `TrajDebug-main.zip`. The archive's Git comment and all 86 blob hashes match commit `5b04f98b1995ec758d9aba70940d17bb7d2d169b` and the previously pinned inventory.

| Verified item | Result |
|---|---:|
| Complete original trajectory files | **86 / 86** |
| Original bytes preserved | **19,844,129** |
| Complete original messages | **10,249 / 10,249** |
| Task specifications and metadata objects | **86 / 86** |
| Graph nodes | **23,541** |
| Directed graph edges | **44,699** |
| Source-linked textual tool invocations parsed | **4,709** |
| Evidence references checked | **82,729** |
| Automated tests | **46 passed**: 28 implementation tests + 18 real-corpus integration tests |

The messages include 86 system messages, 157 user messages, 5,038 assistant messages, and 4,968 tool messages. The 86 attempts span 57 conservative issue groups, seven repositories, and four historical model labels. This is the English release; the original paired Chinese edition and unrelated benchmark subsets are not duplicated here.

**What “complete” means:** every byte in these 86 released files is retained. It does not mean that the original logging captured every environment event. A marker scan found 119 messages with pre-existing clipping/truncation markers; those messages remain unchanged. Unlogged filesystem state or text clipped before release cannot be reconstructed from this archive.

## Two layers, no discarded context

**Evidence layer:** `data/raw_sources/C001.json` through `C086.json` are byte-identical originals. The same bytes are also embedded in SQLite. All message fields, metadata, task text, command strings, recorded code edits, observations, later tests, reversals, and final available messages survive. Unknown fields are preserved too.

**Graph layer:** `data/graph.json` includes a node for every complete message, alongside task, annotation, outcome, tool-invocation, reported exit-code, reported test-summary, and path-reference nodes. Source documents retain every root JSON field outside the message array. Reconstructing a source document from these nodes produces exactly the same decoded JSON values as its original file.

Graph edges identify membership, message order, source provenance, annotation targets, tool mentions and path arguments. They do **not** turn chronology into causation. Each evidence pointer resolves to the original document or an exact Unicode character span, with a digest for verification. `NEXT_MESSAGE` means “next recorded message,” not “causes.”

## Files

| File | Purpose |
|---|---|
| `data/memory.sqlite` | Preferred runtime storage for agents: indexed messages, graph, exact original bytes, and BM25 keyword search. |
| `graph_reader.py` | Read-only search, message pagination, neighborhood traversal, and evidence access. |
| `data/graph.json` | Portable, self-describing full graph; larger than a suitable model context. |
| `data/raw_sources/` | All 86 byte-for-byte originals. |
| `data/messages.jsonl` | Every full message as a streaming record. |
| `data/nodes.jsonl`, `data/edges.jsonl` | Streaming graph exports. |
| `data/cases.jsonl` | Case identity, annotation, message count, and syntax-based operation bookmarks. |
| `data/flat_memory.jsonl` | The same node payloads and evidence, without relationships. Edge-encoded facts must also be matched for a fully equal-information experimental control. |
| `data/source_manifest.json` | Original filenames, paths, hashes, repository/model/issue labels, and per-case message counts. |
| `data/legacy_source_fidelity_audit.json` | All earlier excerpts compared against the now-available originals. |
| `verification/full_corpus_verification.json` | Per-file archive equality, JSON reconstruction, schema, database, and source-pointer checks. |
| `verification/all_tests.txt` | Output of the 46 tests actually run. |
| `AGENT_GUIDE.md`, `agent_tools.json` | Integration instructions and provider-neutral tool descriptions. |
| `examples/` | Source-linked walkthroughs of the previously discussed regression and rollback examples. |
| `upstream_documents/` | Original release manifest, notices, license, and citation information. |

## Use immediately

Python 3.10 or newer; no model API, GPU, or database server is required. The SQLite build provided here has an FTS5 index. An agent needs a host capable of running the reader tools; the model does not execute SQL itself.

From this package directory:

```bash
python graph_reader.py stats
python graph_reader.py search "SIGSEGV" --limit 5
python graph_reader.py case C018 --start 88 --limit 8
python graph_reader.py message C018 89 --max-chars 6000
python graph_reader.py neighbors C018:message:92 --hops 1 --max-nodes 25
python graph_reader.py evidence C018:message:92:call:0 --max-chars 6000
```

Long messages are paginated. Follow `next_start_char`; nothing is removed from storage. `case` lists message previews and syntax-based test/repository/rollback bookmarks. These hints are not semantic assertions that a test passed or a rollback succeeded.

The graph also preserves reported shell exit codes separately from test-report text. A wrapper exit code of zero is not proof of test success. Last assistant/last recorded message markers are not guaranteed final submitted filesystem snapshots.

Several agents may read the same frozen SQLite database. Collective writing, learned confidence, automatic knowledge promotion, and model training are not implemented in this release.

## What changed from the compact graph

Previously, all case IDs were represented but only 173 messages supplied selected evidence. **Now all 10,249 messages are present.** The later test failure, regressive edit, and passing old test in C018, and the rollback after the malformed edit in C062, are no longer missing.

All 86 earlier annotation/reward records match the originals. Of 261 earlier quotations, **258 match exactly** at their recorded pointer. Three quotations in C021/C033 differ in formatting or string escaping. They are retained in the audit but excluded as exact-evidence nodes; the complete original text is present. All 25 earlier task quotations match a source user message. Nine prior premise/decision pairs are retained only as **unreviewed legacy hypotheses**; exact source text does not validate an interpretation.

## Reproduce and verify

```bash
# Rebuild from included byte-identical raw files; choose a new output directory.
python build_full_graph.py --source-root data --output rebuilt_data

# Verify the delivered raw files, all graph messages, SQLite, and manifest membership.
python verify_delivery.py

# Additionally compare every source byte to the uploaded repository archive.
python verify_delivery.py --repository-zip /path/to/TrajDebug-main.zip

python -m unittest discover -s tests -v
```

The importer and reader use only the Python standard library. Optional `jsonschema` is required for the extra JSON Schema check; that check was available and passed in this delivery. Source commands are **never executed** by ingestion, retrieval, or these tests.

## Research boundaries

This delivery establishes **complete source preservation and an evidence-linked graph**, not an exhaustive causal analysis. There are zero new benchmark reruns, zero intervention-validated causal edges, and no claim that all 86 failure mechanisms have been independently established. The example walkthroughs are scoped interpretations of cited transcript events, not terminal-cause proofs.

For evaluation, exclude entire issue groups at minimum (multiple models attempt some issues), and preferably hold out repositories. Enforce exclusions in a separate harness tool, not by handing an evaluation agent unrestricted raw-file access. Match model, retrieval opportunities, token budgets, and all evidence/relationship facts when comparing graph retrieval with a flat baseline. Graph representation is not itself a demonstrated research improvement.

See `SOURCE_NOTICES.md` and the original upstream notices before redistributing source material.
