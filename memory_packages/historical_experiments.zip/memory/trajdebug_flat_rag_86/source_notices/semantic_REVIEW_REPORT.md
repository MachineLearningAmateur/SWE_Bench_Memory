# Semantic review: all 86 TrajDebug SWE-Bench Pro cases

## Result and scope

All **86 cases** now have a provisional semantic assessment. The review concerns **57 issue groups across 7 repositories**, not 86 independent bugs. It is a single-AI, annotation-guided qualitative pass, not an independent benchmark audit, and it did not establish 86 terminal causes.

For each case, the reviewer examined the full released task specification and an abridged chronology covering the record, then expanded relevant original commands, edits, diagnostics, recovery, and late-state evidence. Tool-return summaries and source-code diffs helped select material. This is not a claim that every token in all 10,249 messages was independently understood or validated. Unresolved cases are retained; no label is silently repaired or replaced.

The supplement cites **1,197 complete original messages**, not merely quotations. Each cited message has a case ID, array index, original step, exact JSON pointer, source-file hash, and value digest. All 86 input file hashes and all cited message copies were checked. The original full-evidence graph remains unchanged.

## Primary review classifications

| Classification | Cases | What it does and does not establish |
|---|---:|---|
| Observed local effect or repair | 13 | An effect, bad check, or recovery appears in the trace. Not necessarily a persistent bug. |
| Static conflict with task specification | 22 | A discrepancy against released requirements, not a controlled execution result. |
| Plausible, unconfirmed mechanism | 25 | A concrete risk requiring a trigger or scope check. |
| Agent's stated rationale | 2 | A reason is explicit, but its downstream effect is not established. |
| Unresolved | 24 | No defensible failure mechanism established by this pass. |

These are reviewer classifications, not calibrated confidence scores. They must not be reported as causal-discovery accuracy or as evidence that source labels are wrong. **No case has an intervention-validated terminal-cause conclusion.**

## Important findings and corrections

### C018 — old test feedback induces a requirement regression

The requested change includes signal details. The implementation initially supplies them, a legacy assertion fails, the agent explicitly chooses that assertion over the new behavior, and it removes the details. The old suite then passes. Later readback retains the generic crash output.

Evidence: C018 messages **80, 81, 89, 90, 92, 93, 95, 115** (task in message 1). This is the strongest combination of stated motivation, changed code, failed/passed observation, and persistent late state. It is still not a controlled proof that this one change fully accounts for reward 0.

### C074 — the earlier UI-order diagnosis was only a temporary defect

Message 52 places the status card before the expanded details, contradicting the requirement. But the agent subsequently recognizes the order issue, changes it at **82**, and later readback confirms the corrected arrangement. Any earlier description of that ordering as an unrepaired final defect should be withdrawn.

A separate concern remains: snapshot updates and a test-fixture edit alter the verification baseline. The later pass is not an independent test of the original oracle. Evidence: **52, 80, 82, 89, 114, 121, 129**, with additional supporting messages in the case record. This is a repaired error plus verification risk, not a proven terminal cause.

### C086 — a concrete parser defect is repaired

The first implementation puts an end anchor on the per-token regex inside a loop. Compound durations then fail the reproducer at **61**. The agent diagnoses the anchor, removes it at **64**, and the same compound examples pass at **67**. The corrected implementation remains in the final recorded diff at **83**, and direct task examples pass at **89**.

The source label points to an initial task paraphrase at step 2. That label alone does not explain the later repaired parsing defect or the final failed reward. This case is useful as a negative control: a memory system should not treat a repaired error as the final cause.

### C054 — a failed check is followed by a success declaration

The mixed CLIXML probe at **121** prints `Case 1: FAIL` for an output with changed surrounding newline bytes, then prints `Fix verified.` and exits successfully. This contrasts an actual displayed mismatch with a completion claim and wrapper status.

The candidate lesson is to evaluate the assertions and output bytes, not merely the process exit or the author's success sentence. The review does not claim that the complete official grader was rerun.

### C080 and C082 — visible integration gaps in records that end mid-implementation

C080 retains a missing-symbol reexport and a partly migrated use. C082 adds a filesystem category class and enables it, but no registration in the URL model is recorded before the file ends. These are static discrepancies in the **last available record**. They must not be described as known final submitted patches when no final snapshot is available.

### Some apparent failures remain genuinely unresolved

Several implementations follow the released task and show targeted successful probes, while old assertions expect a previous interface. Others lack usable integration verification. The review leaves those cases unresolved rather than manufacturing a defect to fit a critical-step label. Compare C083 with C018: the same broad test conflict does not imply the same recovery or regression behavior.

## Recurring themes worth testing

**Specification-versus-test conflicts.** Tests can disagree with an explicitly requested interface change. The important question is which contract the agent ultimately implements, not whether some suite passes.

**Disconnected feature integration.** A utility or class can be correct in isolation but never called by the affected runtime path. Trace configuration and API changes to their consumers.

**Verification that does not exercise the claimed behavior.** Examples include copied implementations, a different checkout, fallback returns after an internal error, setup failures, modified expectations, and PASS banners after failed checks.

**Recovery changes attribution.** A local defect may be rolled back or fixed elsewhere. Preserving only its first appearance creates a misleading failure memory.

**Release ambiguity and incomplete observable state.** Some requirements conflict internally, observations were clipped before release, and some records end before final verification. Preserve these limits as part of the graph.

These are candidate analytic themes. The all-failed, selected corpus cannot estimate their population prevalence or establish a causal effect of memory retrieval.

## Graph additions

The new overlay has **2,009 nodes and 2,107 directed edges**. It separates a semantic assessment, end-state assessment, caveat, unvalidated lesson, and proposed validation step for every case. Source-reference nodes resolve to the original message IDs and exact JSON pointers.

There are **50 proposed message-to-message semantic relations** where an explicit statement or concrete local sequence supports a relationship. Other assessments can describe an unresolved or static discrepancy without forcing one of these links. `STATED_MOTIVATES`, `ERROR_PRECEDES_REPAIR_ATTEMPT`, and related edges are provisional interpretations, not intervention-certified facts. Citation edges can represent counterevidence or context, not just support.

Shared issue, repository, and reviewer-category nodes enable cross-case lookup. They do not turn repeated tasks or repeated model outputs into independent confirmations.

## Recommended experiment use

Keep the corpus frozen for the first experiment. Start with the stronger local-mechanism and static-contract candidates, accompanied by counterevidence and scope. Include repaired cases as negative controls. Put all 24 unresolved cases in a separate audit/abstention stratum; do not silently drop them from reporting.

For selected high-value cases, obtain the actual submitted patch and benchmark test patch, reproduce the relevant behavior, and make a matched change. Re-run under the same environment and distinguish local effect from the final reward. This work is proposed in `validation_queue.json`, not performed here.

Evaluate transfer on held-out issues, preferably held-out repositories. Give graph and flat retrieval identical facts, evidence, caveats, and relation descriptions, with matched model and context budgets. Using richer content only in the graph condition would not isolate graph structure.

## LangGraph

Use LangGraph to coordinate retrieval, evidence loading, reasoning, and later execution/verification. Keep the semantic knowledge graph in a separate shared store. The included adapter provides the retrieval/evidence/callback boundary. Its dependency-free stages were tested; **native LangGraph compile/invoke was not tested**, because the package was unavailable in this environment. See `LANGGRAPH_DESIGN.md` for the official API references and boundaries.

## Validation performed

The test run contains **37 methods: 36 passed and one native-LangGraph test was skipped**. Checks cover case membership, metadata, exact message hashes, all source-file bytes, graph endpoints, adjacency, SQLite consistency, flat-data parity, exclusions, pagination, bounded retrieval, and callback execution. These tests check software/data integrity, not semantic truth or causal validity.

## All-case index

Each case card records the assessment, counterevidence, late state, exact evidence references, candidate lesson, and next validation test.

| Case | Primary classification | Review title |
|---|---|---|
| [C001](cases/C001.md) | `stated_rationale` | Password ident parser: legacy arity determines API choice |
| [C002](cases/C002.md) | `spec_contradiction` | Unsafe variable wrapping: legacy tests override required bytes handling |
| [C003](cases/C003.md) | `unresolved` | ICX ping: annotated call-style change is not a demonstrated production defect |
| [C004](cases/C004.md) | `stated_rationale` | WinRM: mock compatibility shapes a split output-retrieval path |
| [C005](cases/C005.md) | `unresolved` | Netrc propagation: marked planning choice has no demonstrated bad effect |
| [C006](cases/C006.md) | `observed_local_effect` | S390 facts: verification imported a different source tree |
| [C007](cases/C007.md) | `spec_contradiction` | Kerberos refactor reduced to minor edits to preserve old tests |
| [C008](cases/C008.md) | `plausible_unconfirmed` | CLIXML: whole-input fallback can discard earlier successful decoding |
| [C009](cases/C009.md) | `plausible_unconfirmed` | Admin action locks: render-state guard may not implement immediate member-scoped exclusion |
| [C010](cases/C010.md) | `plausible_unconfirmed` | Search merging: merge direction differs from the original chronological traversal |
| [C011](cases/C011.md) | `plausible_unconfirmed` | Author aggregation: name-only deduplication can lose stronger work metadata |
| [C012](cases/C012.md) | `plausible_unconfirmed` | List consolidation: module boundary and circular-import behavior remain insufficiently checked |
| [C013](cases/C013.md) | `spec_contradiction` | Declarations added without wiring identifier-first author import |
| [C014](cases/C014.md) | `spec_contradiction` | Existing verification fixtures edited despite non-test-only instruction |
| [C015](cases/C015.md) | `plausible_unconfirmed` | Language normalization leaves code conversion and object-shape assumptions untested |
| [C016](cases/C016.md) | `spec_contradiction` | Honorific API and wildcard escaping remain incompatible with specification |
| [C017](cases/C017.md) | `spec_contradiction` | Old tests used to justify separate, unmapped threshold options |
| [C018](cases/C018.md) | `observed_local_effect` | Legacy test feedback motivates a persistent regression against new crash-message requirements |
| [C019](cases/C019.md) | `spec_contradiction` | Smart classifier zero is suppressed and the custom test rewards that mismatch |
| [C020](cases/C020.md) | `unresolved` | Published wrong-verification label not explained by an observed implementation defect |
| [C021](cases/C021.md) | `observed_local_effect` | PID and signal improvements abandoned to satisfy old tests |
| [C022](cases/C022.md) | `plausible_unconfirmed` | Parser format and end-to-end device behavior remain insufficiently checked |
| [C023](cases/C023.md) | `plausible_unconfirmed` | Versioned Python shebangs bypass the preserved override branch |
| [C024](cases/C024.md) | `unresolved` | Upgrade flag wired through without a demonstrated resolver-level failure mechanism |
| [C025](cases/C025.md) | `unresolved` | Constructor-based netrc forwarding is not shown to be a schema error |
| [C026](cases/C026.md) | `plausible_unconfirmed` | Repository-wide version migration remains ambiguous and incompletely verified |
| [C027](cases/C027.md) | `unresolved` | Set-rule construction shown working on examples; terminal mechanism unresolved |
| [C028](cases/C028.md) | `spec_contradiction` | Empty manifest bypasses mutual-exclusion guard; earlier distlib API error is repaired |
| [C029](cases/C029.md) | `plausible_unconfirmed` | CLIXML replacement relies on string-balanced blocks without a verified mixed-block recovery test |
| [C030](cases/C030.md) | `plausible_unconfirmed` | Space-change branch returns before later React hooks |
| [C031](cases/C031.md) | `plausible_unconfirmed` | Shared pending state lacks a demonstrated synchronous member-scoped action gate |
| [C032](cases/C032.md) | `plausible_unconfirmed` | One-time device snapshot and refresh semantics are not independently validated |
| [C033](cases/C033.md) | `spec_contradiction` | Cached derived fields contaminate equality; delimiter parsing can drop metadata |
| [C034](cases/C034.md) | `unresolved` | Language extraction is implemented; observed test failure is an output-schema mismatch |
| [C035](cases/C035.md) | `observed_local_effect` | Unrequested fallback to an arbitrary available Wikipedia language |
| [C036](cases/C036.md) | `spec_contradiction` | Strong identifier matches are still filtered by legacy date-presence rules |
| [C037](cases/C037.md) | `spec_contradiction` | A permissive date helper is reused where exact dates or no dates are required |
| [C038](cases/C038.md) | `unresolved` | Transactional recovery is added, but the multi-layer API contract is unverified |
| [C039](cases/C039.md) | `unresolved` | Resolver assumptions are exercised only after adapting the test doubles |
| [C040](cases/C040.md) | `unresolved` | Typing refactor is not validated through an importable production test path |
| [C041](cases/C041.md) | `unresolved` | Normalizer unit examples pass while legacy MARC fixtures disagree |
| [C042](cases/C042.md) | `observed_local_effect` | Nil cache values expose an assertion panic that is subsequently guarded |
| [C043](cases/C043.md) | `observed_local_effect` | A cancellation refactor introduces a syntax error and then repairs it |
| [C044](cases/C044.md) | `unresolved` | Hook extraction appears consistent, but the new decision table is never directly tested |
| [C045](cases/C045.md) | `unresolved` | Version-aware rename appears implemented; test abort leaves the failure unexplained |
| [C046](cases/C046.md) | `plausible_unconfirmed` | Path-completion model is revised, but URL normalization remains untested |
| [C047](cases/C047.md) | `unresolved` | The annotated state-string change follows the task; real Qt verification is blocked |
| [C048](cases/C048.md) | `unresolved` | Passing pre-existing utility tests does not exercise the newly inserted parser |
| [C049](cases/C049.md) | `plausible_unconfirmed` | New image policy is not propagated to an older-version consumer |
| [C050](cases/C050.md) | `observed_local_effect` | Parser rollback is followed by an alternative run-level repair |
| [C051](cases/C051.md) | `unresolved` | Version-floor ambiguity, with extraction API repair verified locally |
| [C052](cases/C052.md) | `plausible_unconfirmed` | Repeated edit failures are repaired, with an all-zero serial edge remaining |
| [C053](cases/C053.md) | `plausible_unconfirmed` | Core date-deprecation support added, broader validation scope omitted |
| [C054](cases/C054.md) | `observed_local_effect` | CLIXML replacement drops a surrounding carriage return and ignores its own failed check |
| [C055](cases/C055.md) | `spec_contradiction` | Post-render update retains the stale-render window, while test timeout is reported as success |
| [C056](cases/C056.md) | `plausible_unconfirmed` | Nested dialog retains an import path copied from the parent directory |
| [C057](cases/C057.md) | `spec_contradiction` | Knock upgrade path bypasses the existing coordinated upgrade callback |
| [C058](cases/C058.md) | `spec_contradiction` | Expansion helpers are left outside the requested public module |
| [C059](cases/C059.md) | `plausible_unconfirmed` | Robust helper behavior is added under names different from the requested interface |
| [C060](cases/C060.md) | `plausible_unconfirmed` | Publisher normalization can create empty records after punctuation stripping |
| [C061](cases/C061.md) | `unresolved` | Annotated indentation problem is repaired and missing-author examples succeed |
| [C062](cases/C062.md) | `observed_local_effect` | Overbroad insertion is reverted; final constructor still makes required context optional |
| [C063](cases/C063.md) | `plausible_unconfirmed` | Main CLI cases work; Optional unwrapping retains a None-first union hazard |
| [C064](cases/C064.md) | `plausible_unconfirmed` | Typed cache wrapper still asserts potentially nil interface values |
| [C065](cases/C065.md) | `spec_contradiction` | Correct expiry utility is not wired into an affected cancellation screen |
| [C066](cases/C066.md) | `spec_contradiction` | Extracted eligibility hook can return undefined instead of a boolean |
| [C067](cases/C067.md) | `unresolved` | Foreground-threshold implementation is present; integration verification is inconclusive |
| [C068](cases/C068.md) | `unresolved` | Repeated editing faults are repaired but no successful integration check is recorded |
| [C069](cases/C069.md) | `spec_contradiction` | Prefix-only validation accepts an empty custom statusbar widget |
| [C070](cases/C070.md) | `spec_contradiction` | SIGTERM classification is added but informational messages omit required process ID |
| [C071](cases/C071.md) | `spec_contradiction` | Request-level encoding is implemented instead of the demonstrated per-file encoding |
| [C072](cases/C072.md) | `unresolved` | Sysinfo helper and integration pass targeted probes; annotated mechanism remains unresolved |
| [C073](cases/C073.md) | `spec_contradiction` | Compatibility with old error assertions preserves an error-message contract mismatch |
| [C074](cases/C074.md) | `observed_local_effect` | UI-order defect is repaired, while snapshot updates weaken independent verification |
| [C075](cases/C075.md) | `observed_local_effect` | Package-name collision breaks the build and is repaired by an import alias |
| [C076](cases/C076.md) | `unresolved` | IA normalization is integrated and demonstrated; critical helper defect not established |
| [C077](cases/C077.md) | `plausible_unconfirmed` | Typed-list support works in probes; CLI naming and optional-union boundaries remain untested |
| [C078](cases/C078.md) | `observed_local_effect` | A tuple-shape test passes after the real work-update path raises and is caught |
| [C079](cases/C079.md) | `plausible_unconfirmed` | New LCCN helper is tested in isolation but not connected to record processing |
| [C080](cases/C080.md) | `spec_contradiction` | Partial constants migration reexports a missing symbol and removes a still-used import |
| [C081](cases/C081.md) | `plausible_unconfirmed` | A parallel telemetry selector may disagree with the actual download mechanism |
| [C082](cases/C082.md) | `spec_contradiction` | A new completion category is enabled in configuration but never registered before the record ends |
| [C083](cases/C083.md) | `unresolved` | New signal behavior is retained despite incompatible legacy assertions; terminal cause unresolved |
| [C084](cases/C084.md) | `unresolved` | A transient import-visibility failure is followed by successful direct parser probes |
| [C085](cases/C085.md) | `unresolved` | The Qt 6.6 policy implementation matches its displayed probes; failure attribution remains unresolved |
| [C086](cases/C086.md) | `observed_local_effect` | An end-anchored regex rejects compound durations and is explicitly repaired |
