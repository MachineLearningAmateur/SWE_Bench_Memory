# Source and attribution

Source repository: https://github.com/THU-KEG/TrajDebug
Pinned commit: 5b04f98b1995ec758d9aba70940d17bb7d2d169b
Pinned subset: data/trajerrbench/en/swebenchpro
Pinned directory tree SHA: 67a736cefb333882ec2ce81568dbaceb9769bc80

The repository documents 86 paired English/Chinese SWE-Bench Pro-derived failed trajectories.
This importer targets the English release. Its task IDs, reward and critical-error labels are
inherited from the paired Chinese release according to data/trajerrbench/README.md.

Citation: TRAJDEBUG: Tracing Error Lifecycle to Identify Critical Failures in Long-Horizon Agent
Trajectories, arXiv:2608.06346. Preserve the authors' attribution when reporting results.

The pinned data/README.md says the repository MIT license covers TRAJDEBUG code and original
annotations, but does not relicense upstream task text, trajectories, environments or repositories.
Review their original terms before redistributing the downloaded source corpus. This package does
not claim blanket MIT coverage for source data or quotations.

This is an independent implementation, not an official TrajDebug dataset release. This delivery contains the 86 complete English source files supplied by the user, with original
bytes preserved. Legacy inputs contain the previous compact source-linked extracts and are kept
only for comparison. Original upstream notices are preserved in upstream_documents/.
