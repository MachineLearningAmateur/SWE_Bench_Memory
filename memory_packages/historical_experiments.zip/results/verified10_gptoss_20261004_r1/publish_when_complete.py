"""Finish the user-authorized publication only after this batch is complete."""
import hashlib
import json
import os
import subprocess
import time
from datetime import datetime, timezone
from pathlib import Path

BATCH = Path(__file__).resolve().parent
ROOT = BATCH.parents[1]
PLAN = json.loads((BATCH / "publication_plan.json").read_text())
STATUS = BATCH / "publication_status.json"


def status(state, **kwargs):
    value = {"state": state, "pid": os.getpid(), "updated_utc": datetime.now(timezone.utc).isoformat(), **kwargs}
    temporary = STATUS.with_suffix(".tmp")
    temporary.write_text(json.dumps(value, indent=2) + "\n")
    temporary.replace(STATUS)


def git_output(*args):
    return subprocess.check_output(["git", *args], cwd=ROOT, text=True).strip()


def check_sources():
    if git_output("branch", "--show-current") != PLAN["branch"] or git_output("rev-parse", "HEAD") != PLAN["expected_head"]:
        raise RuntimeError("Branch or HEAD changed since publication was prepared")
    for name, expected in PLAN["source_sha256"].items():
        if hashlib.sha256((ROOT / name).read_bytes()).hexdigest() != expected:
            raise RuntimeError(f"Reviewed source changed: {name}")
    if git_output("diff", "--cached", "--name-only"):
        raise RuntimeError("Index is not empty; refusing to disturb staged work")


def main(log):
    with (BATCH / "publication_started.json").open("x") as f:
        json.dump({"pid": os.getpid(), "started_utc": datetime.now(timezone.utc).isoformat()}, f)
    check_sources()
    while True:
        batch_status = json.loads((BATCH / "status.json").read_text())
        if batch_status["state"] == "complete":
            break
        status("waiting_for_batch", batch_status=batch_status)
        time.sleep(30)
    check_sources()
    status("exporting")
    subprocess.run(["docker", "exec", PLAN["container"], "python", "-m", "src.verified_report",
                    "--input", "/workspace/results/" + BATCH.name,
                    "--output", "/workspace/audit/gpt_oss_20b/verified10_results.json",
                    "--analysis", "/workspace/docs/gpt_oss_20b_verified10_results.md"],
                   cwd=ROOT, stdout=log, stderr=subprocess.STDOUT, check=True)
    # Check actual configured secret values without printing any value or raw environment.
    scan = (
        "from pathlib import Path\nfrom dotenv import dotenv_values\nimport json\n"
        "values=dotenv_values('/workspace/.env')\n"
        "secrets=[v for k,v in values.items() if v and len(v)>=12 and "
        "any(s in k.upper() for s in ('KEY','TOKEN','SECRET','PASSWORD','API_BASE','ENDPOINT'))]\n"
        f"files={PLAN['files']!r}\n"
        "assert all(not any(s in (Path('/workspace')/p).read_text(encoding='utf-8') for s in secrets) for p in files), 'Secret scan failed'\n"
        "print('Configured-secret scan passed')\n"
    )
    subprocess.run(["docker", "exec", PLAN["container"], "python", "-c", scan],
                   cwd=ROOT, stdout=log, stderr=subprocess.STDOUT, check=True)
    check_sources()
    subprocess.run(["git", "add", "--", *PLAN["files"]], cwd=ROOT, stdout=log, stderr=subprocess.STDOUT, check=True)
    subprocess.run(["git", "diff", "--cached", "--check"], cwd=ROOT, stdout=log, stderr=subprocess.STDOUT, check=True)
    status("committing")
    subprocess.run(["git", "commit", "--only", "-m", PLAN["commit_message"], "--", *PLAN["files"]],
                   cwd=ROOT, stdout=log, stderr=subprocess.STDOUT, check=True)
    commit = git_output("rev-parse", "HEAD")
    status("pushing", commit=commit)
    subprocess.run(["git", "push", "origin", "HEAD:refs/heads/main"], cwd=ROOT,
                   stdout=log, stderr=subprocess.STDOUT, check=True)
    remote = git_output("ls-remote", "origin", "refs/heads/main").split()[0]
    if remote != commit:
        raise RuntimeError("Remote HEAD does not match the published commit")
    status("published", commit=commit, branch="main", remote="origin")


if __name__ == "__main__":
    with (BATCH / "publication.log").open("a", encoding="utf-8", buffering=1) as log:
        try:
            main(log)
        except Exception as exc:
            status("stopped", error_type=type(exc).__name__, reason=str(exc))
            import traceback
            traceback.print_exc(file=log)
            raise SystemExit(1)
